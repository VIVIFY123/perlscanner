my $cmd = param('user');
system($cmd);
