#!/usr/bin/perl
use strict;
use warnings;
use JSON;
use File::Find;


# Load rules
my $rules_file = 'rules.json';
open my $rfh, '<:encoding(UTF-8)', $rules_file or die "Cannot open rules file: $!";
my $rules_json = do { local $/; <$rfh> };
close $rfh;
my $rules = decode_json($rules_json);

# Directory to scan
my $target_dir = $ARGV[0] or die "Usage: $0 <directory>";

# Store results
my @findings;
my $id_counter = 1;

# Recursively scan Perl files
find(\&scan_file, $target_dir);

# Output JSON results
open my $out, '>:encoding(UTF-8)', 'results.json' or die $!;
print $out encode_json(\@findings);
close $out;

# ----------- Functions -----------

sub scan_file {
    return unless /\.pl$/;
    my $filepath = $File::Find::name;
    open my $fh, '<:encoding(UTF-8)', $_ or return;

    my @lines = <$fh>;
    close $fh;

    for (my $i = 0; $i < @lines; $i++) {
        my $line = $lines[$i];
        chomp($line);

        # 1. Pattern-based rules
        foreach my $rule (@$rules) {
            my $severity = lc($rule->{severity} // "medium");

            if (exists $rule->{pattern}) {
                my $regex = qr/$rule->{pattern}/;
                if ($line =~ $regex) {
                    push @findings, {
                        id       => sprintf("FIND-%04d", $id_counter++),
                        file     => $filepath,
                        line     => $i + 1,
                        code     => $line,
                        issue    => $rule->{issue},
                        owasp    => $rule->{owasp} // "",
                        cwe      => $rule->{cwe}   // "",
                        severity => $severity,
                        type     => "Pattern-Based",
                        context  => get_context_lines(\@lines, $i)
                    };
                }
            }

            # 2. Taint tracking: source-to-sink
            elsif (exists $rule->{sink} && exists $rule->{source} && $line =~ /\b\Q$rule->{sink}\E\b/) {
                foreach my $j (0 .. $#lines) {
                    if ($lines[$j] =~ /\b\Q$rule->{source}\E\b/) {
                        push @findings, {
                            id       => sprintf("FIND-%04d", $id_counter++),
                            file     => $filepath,
                            line     => $i + 1,
                            code     => $line,
                            issue    => $rule->{issue},
                            owasp    => $rule->{owasp} // "",
                            cwe      => $rule->{cwe}   // "",
                            severity => $severity,
                            type     => "Taint-Based",
                            sink     => $rule->{sink},
                            source   => $rule->{source},
                            variable => extract_variable($line),
                            context  => get_context_lines(\@lines, $i)
                        };
                        last;
                    }
                }
            }
        }

        # 3. Structural: sub with no auth/logging
        if ($line =~ /^\s*sub\s+(\w+)\s*\{/) {
            my $sub_name = $1;
            my $start_line = $i;
            my $brace_count = 1;
            my $j = $i + 1;
            my $has_auth = 0;

            while ($j < @lines && $brace_count > 0) {
                my $l = $lines[$j];
                $brace_count++ if $l =~ /\{/;
                $brace_count-- if $l =~ /\}/;
                if ($l =~ /(password|auth|validate|log|csrf|token|session)/i) {
                    $has_auth = 1;
                }
                $j++;
            }

            if (!$has_auth) {
                push @findings, {
                    id       => sprintf("FIND-%04d", $id_counter++),
                    file     => $filepath,
                    line     => $start_line + 1,
                    code     => $line,
                    issue    => "Suspicious Subroutine – No Auth/Validation",
                    owasp    => "A07:2021-Identification and Authentication Failures",
                    cwe      => "CWE-778",
                    severity => "low",
                    type     => "Structural",
                    context  => get_context_lines(\@lines, $start_line)
                };
            }
        }

        # 4. Structural: eval block without error handling
        if ($line =~ /^\s*eval\s*\{/) {
            my $start_line = $i;
            my $brace_count = 1;
            my $j = $i + 1;
            my $has_handler = 0;

            while ($j < @lines && $brace_count > 0) {
                my $l = $lines[$j];
                $brace_count++ if $l =~ /\{/;
                $brace_count-- if $l =~ /\}/;
                if ($l =~ /(warn|die|log|catch|if\s*\(\s*\$@\s*\))/i) {
                    $has_handler = 1;
                }
                $j++;
            }

            if (!$has_handler) {
                push @findings, {
                    id       => sprintf("FIND-%04d", $id_counter++),
                    file     => $filepath,
                    line     => $start_line + 1,
                    code     => $line,
                    issue    => "Eval Block – No Error Handling",
                    owasp    => "A09:2021-Logging and Monitoring Failures",
                    cwe      => "CWE-703",
                    severity => "medium",
                    type     => "Structural",
                    context  => get_context_lines(\@lines, $start_line)
                };
            }
        }

        # 5. ENV exposure
        if ($line =~ /\$ENV\{.*\}/) {
            push @findings, {
                id       => sprintf("FIND-%04d", $id_counter++),
                file     => $filepath,
                line     => $i + 1,
                code     => $line,
                issue    => "Sensitive Environment Variable Exposure",
                owasp    => "A05:2021-Security Misconfiguration",
                cwe      => "CWE-538",
                severity => "low",
                type     => "Structural",
                context  => get_context_lines(\@lines, $i)
            };
        }

        # 6. Unsafe open() paths
        if ($line =~ /open\s*\(.*\$(\w+)/) {
            push @findings, {
                id       => sprintf("FIND-%04d", $id_counter++),
                file     => $filepath,
                line     => $i + 1,
                code     => $line,
                issue    => "Insecure File Open – Path from Variable",
                owasp    => "A05:2021-Security Misconfiguration",
                cwe      => "CWE-73",
                severity => "medium",
                type     => "Structural",
                context  => get_context_lines(\@lines, $i)
            };
        }

        # 7. Dangerous command subroutines
        if ($line =~ /^\s*sub\s+(install|update|upgrade|sync)\s*\{/) {
            my $sub_name = $1;
            my $start_line = $i;
            my $brace_count = 1;
            my $j = $i + 1;
            my $has_system = 0;

            while ($j < @lines && $brace_count > 0) {
                my $l = $lines[$j];
                $brace_count++ if $l =~ /\{/;
                $brace_count-- if $l =~ /\}/;
                if ($l =~ /(system|exec|`.*`)/) {
                    $has_system = 1;
                }
                $j++;
            }

            if ($has_system) {
                push @findings, {
                    id       => sprintf("FIND-%04d", $id_counter++),
                    file     => $filepath,
                    line     => $start_line + 1,
                    code     => $line,
                    issue    => "Command Execution in Critical Subroutine ($sub_name)",
                    owasp    => "A03:2021-Injection",
                    cwe      => "CWE-78",
                    severity => "high",
                    type     => "Structural",
                    context  => get_context_lines(\@lines, $start_line)
                };
            }
        }
    }
}

sub extract_variable {
    my ($line) = @_;
    if ($line =~ /(\$\w+)/) {
        return $1;
    }
    return '';
}

sub get_context_lines {
    my ($lines_ref, $bad_line_index) = @_;
    my @context;
    my $start = $bad_line_index - 2;
    my $end   = $bad_line_index + 2;

    for my $i ($start .. $end) {
        next if $i < 0 || $i >= @$lines_ref;
        push @context, {
            number    => $i + 1,
            code      => $lines_ref->[$i],
            highlight => ($i == $bad_line_index) ? JSON::true : JSON::false
        };
    }

    return \@context;
}

