my $bad = param('filename');
open(FILE, "<$bad");

