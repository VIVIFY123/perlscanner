# test1.pl - Contains multiple security issues

print "Enter your name: ";
my $name = <STDIN>;

# 🚨 Command Injection
print "Running your command...\n";
my $input = <STDIN>;
system($input);  # UNSAFE

# 🚨 Path Traversal & File Access
print "Which file to read?\n";
my $bad = <STDIN>;
open(FILE, "<$bad");  # UNSAFE
while (<FILE>) {
    print;
}
close(FILE);

# 🚨 Unsafe echo (XSS potential if used in CGI)
print "Hello, $name";  # No escaping

# 🚨 Insecure login
my $user_input = <STDIN>;
my $pass = <STDIN>;
if ($user_input eq "admin" && $pass eq "password123") {  # Hardcoded creds
    print "Welcome admin\n";
} else {
    print "Access denied\n";
}

