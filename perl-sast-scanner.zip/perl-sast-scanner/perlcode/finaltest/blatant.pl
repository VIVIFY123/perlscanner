#!/usr/bin/perl
use strict;
use warnings;
use CGI;
use LWP::UserAgent;
use Digest::MD5 qw(md5_hex);               # CWE-327: Use of MD5
use Data::Dumper;                          # CWE-117: Debug Module Enabled
use Crypt::DES;                            # CWE-327: Weak Cipher
use JSON;
use Fcntl qw(:DEFAULT :flock);
use POSIX qw(tmpnam);

# CWE-798: Hardcoded credentials
my $admin_password = "SuperSecret123";
my $api_key = "apikey12345678";

# CWE-538: Exposed config file
require "./config.pl";

# User input sources
my $q = CGI->new;
my $input = $q->param('input');            # CWE-20: Unvalidated input
my $file = $q->param('file');
my $cmd = $q->param('cmd');
my $user = $q->param('user');
my $pass = $q->param('pass');

# CWE-703: Improper Exception Handling
eval {
    my $risky = risky_function($input);
};

# CWE-476: NULL Dereference
my $undef_var;
print length($undef_var);                  # Null deref risk

# CWE-190: Integer overflow
my $big = 999999 * 999999999;

# CWE-840: Business Logic Flaw
my $balance = -1000;
if ($balance < 0) {
    print "Processing refund...\n";
}

# CWE-77: Command Injection via backticks
my $result = `$cmd`;                       # Dangerous if $cmd is not validated

# CWE-78: Unescaped user input in command
system("ping $input");

# CWE-73 + CWE-22: Direct file access + Path traversal
open(my $fh, "<", $file) or die "Can't open $file";

# CWE-434: Unrestricted File Upload
my $upload = $q->upload('file');          # No checks on upload

# CWE-94 + CWE-95: Eval from input
eval($input);

# CWE-502: Deserialization of untrusted data
my $json = $q->param('json');
my $decoded = eval { decode_json($json) };  # No validation

# CWE-601: Unvalidated Redirect
my $redir = $q->param('redir');
print $q->redirect($redir);               # No domain whitelist

# CWE-287: Broken Authentication
if ($user eq 'admin') {                   # No password check
    print "Logged in as admin\n";
}

# CWE-1390: Auth bypass with blank input
if ($user eq '') {
    print "Access granted\n";
}

# CWE-285 + CWE-306 + CWE-863: Access control flaws
if ($q->param('page') eq '/admin') {
    print "Admin page loaded\n";          # No role check
}

# CWE-276: Incorrect permissions
chmod(0777, "./sensitive.txt");

# CWE-276: Permissive umask
umask(0000);

# CWE-256: Plaintext credential storage
store($user, $pass);

# CWE-778: Missing auth logs
sub login {
    print "Login logic here\n";           # No logging
}

# CWE-209: Error message leakage
die("Failed to process user: $user");     # Leaks input

# CWE-116: XSS from output
print $q->param("name");                  # No HTML escaping

# CWE-117: Improper neutralization in logs
my $log = "User login: $user\n";
print LOG $log;

# CWE-377: Insecure temporary file creation
my $tmp = tmpnam();
open my $tfh, ">", $tmp;

# CWE-362: Race condition
if (fork() == 0) {
    print "Child process doing stuff\n";
    exit;
}

# CWE-327: Use of MD5
my $digest = md5_hex($pass);

# CWE-338: Weak random number
my $token = int(rand(1000000));

# CWE-1333: Weak input regex
if ($input =~ /.*password.*/) {
    print "Found password\n";
}

# CWE-352: Missing CSRF token
print "<form action='/submit' method='POST'>";  # No CSRF token
print "<input name='data'>";
print "</form>";

# CWE-798: Hardcoded secret used in logic
if ($api_key eq "apikey12345678") {
    print "API Access granted\n";
}

# CWE-117: Logging unsanitized input
sub log_action {
    my $msg = shift;
    open my $log, '>>', 'logfile.log';
    print $log "LOG: $msg\n";             # CWE-117
    close $log;
}

# CWE-119: Buffer operation risk
my $str = "abc";
my $substr = substr($str, -5, 2);         # Negative index access

# CWE-306: Missing auth on critical route
if ($q->param("route") eq "/admin/settings") {
    print "Changing admin settings...\n";
}

sub risky_function {
    return $_[0] * 2;
}

sub store {
    my ($u, $p) = @_;
    open my $db, ">>", "users.txt";
    print $db "$u:$p\n";                  # Plaintext credential storage
    close $db;
}

