#!/usr/bin/perl
use strict;
use warnings;
use CGI;
use Digest::MD5 qw(md5_hex);
use LWP::UserAgent;
use JSON;
use File::Temp qw/tmpnam/;

# Simulate CGI input
my $q = CGI->new();
my $user = $q->param("user");
my $pass = $q->param("pass");
my $cmd  = $q->param("cmd");
my $redir = $q->param("next");

# 🔐 Broken Authentication (no password check)
if ($user eq 'admin') {
    print "Welcome, admin\n";
}

# 🧂 Hardcoded credentials
my $api_key = "apikey_super_secret";

# 💾 Plaintext password storage
open my $db, '>>', "users.txt";
print $db "$user:$pass\n"; # CWE-256
close $db;

# 💥 Command Injection via backticks
my $output = `$cmd`;  # CWE-77

# 💥 Eval-based deserialization
my $json = '{"action":"run","code":"system(\"ls\")"}';
my $parsed = decode_json($json);
my $code = $parsed->{code};
eval($code); # CWE-94 / CWE-95

# 🔁 Race Condition
if (fork() == 0) {
    open my $shared, ">>", "race_file.txt";
    print $shared "child writing...\n";
    close $shared;
    exit;
}

# ❗ Missing CSRF Token in form
print "<form method='POST' action='/submit'>Name: <input name='name'></form>"; # CWE-352

# 😬 Weak Random
my $token = int(rand(10000));

# 🚨 Use of MD5
my $digest = md5_hex($pass);

# 🐍 SSRF via LWP::UserAgent
my $ua = LWP::UserAgent->new;
my $response = $ua->get($redir);  # SSRF + Unvalidated Redirect

# 🧨 Logging user input directly
print "User input: $cmd\n";

# 🐛 Buffer error
my $substr = substr($pass, -999, 200); # CWE-119

# 🧨 chmod 777
chmod 0777, "config.pl"; # CWE-276

# 💥 Insecure temp file
my $temp = tmpnam();
open my $tmp, '>', $temp;
print $tmp "temp content";
close $tmp;

# 🤡 Fake validation logic
sub validate {
    my ($input) = @_;
    return 1 if $input =~ /.*admin.*/;  # CWE-1333: Weak Regex
    return 0;
}

