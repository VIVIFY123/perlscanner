#!/usr/bin/env python3

import os
import subprocess
import json
from collections import Counter, defaultdict

def ask_code_directory():
    while True:
        path = input("📁 Where is your Perl code directory? ").strip()
        if os.path.isdir(path):
            return os.path.abspath(path)
        print("❌ Invalid directory. Try again.")

def ask_report_name():
    while True:
        name = input("📝 What is the name of your report (no extension)? ").strip()
        if name and not any(c in name for c in r'<>:"/\|?*'):
            return name
        print("❌ Invalid name. Avoid special characters.")

def run_scan(code_dir):
    taint_script = os.path.join(os.getcwd(), "taint_engine.pl")
    if not os.path.exists(taint_script):
        print("❌ taint_engine.pl not found.")
        return None

    print(f"🔍 Scanning {code_dir} using taint_engine.pl")

    try:
        subprocess.run(["perl", taint_script, code_dir], check=True)
        if os.path.exists("results.json"):
            with open("results.json", "r") as f:
                return json.load(f)
        else:
            print("⚠️ No findings found (results.json missing).")
            return []
    except subprocess.CalledProcessError as e:
        print(f"❌ Scan failed: {e}")
        return []

def save_json(findings, json_path):
    with open(json_path, "w") as f:
        json.dump(findings, f, indent=2)
    print(f"💾 JSON saved to: {json_path}")

def save_html(findings, html_path):
    severity_counts = Counter(f['severity'].lower() for f in findings)
    file_counts = defaultdict(int)
    for fnd in findings:
        file_counts[fnd['file']] += 1
    most_vulnerable = sorted(file_counts.items(), key=lambda x: x[1], reverse=True)

    highs = [f for f in findings if f['severity'].lower() == 'high']
    mediums = [f for f in findings if f['severity'].lower() == 'medium']
    lows = [f for f in findings if f['severity'].lower() == 'low']

    with open(html_path, "w", encoding="utf-8") as f:
        f.write("""<!DOCTYPE html><html><head><title>Perl SAST Report</title>
<style>
body { font-family: sans-serif; margin: 2rem; }
h1, h2 { margin-bottom: 0.3rem; }
.bar-container { display: flex; align-items: center; margin: 6px 0; }
.bar-label { width: 100px; }
.bar { height: 20px; background-color: #007bff; margin-left: 10px; color: white; text-align: right; padding-right: 5px; line-height: 20px; }
table { border-collapse: collapse; width: 100%; margin-bottom: 2rem; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
th { background-color: #f4f4f4; }
code { background-color: #f9f9f9; padding: 2px 4px; border-radius: 4px; display: inline-block; }
details { margin-bottom: 1rem; }
summary { font-weight: bold; cursor: pointer; margin-top: 10px; }
.context-line { white-space: pre-wrap; font-family: monospace; padding-left: 1rem; }
.highlight { background-color: #ffeeba; }
</style>
</head><body>
<h1>🛡️ Perl SAST Report</h1>
""")

        # 🧠 Summary
        f.write(f"<h2>🧠 Summary</h2>\n")
        f.write(f"<p><strong>Total Findings:</strong> {len(findings)}</p>\n")

        # 📊 Severity Chart
        f.write("<h2>📊 Severity Breakdown</h2>\n")
        for sev in ['high', 'medium', 'low']:
            count = severity_counts.get(sev, 0)
            width = int((count / max(sum(severity_counts.values()), 1)) * 300)
            f.write(f"""<div class="bar-container"><div class="bar-label">{sev.capitalize()}</div>
<div class="bar" style="width:{width}px">{count}</div></div>\n""")

        # ⚠️ Most Vulnerable Files
        f.write("<h2>⚠️ Most Vulnerable Files</h2>\n")
        f.write("<table><tr><th>File</th><th>Findings</th></tr>")
        for file, count in most_vulnerable:
            f.write(f"<tr><td>{file}</td><td>{count}</td></tr>")
        f.write("</table>\n")

        # 📄 Full Table with Context (sorted)
        def render_group(title, group):
            f.write(f"<h3>{title}</h3>\n")
            f.write("<table><tr><th>File</th><th>Line</th><th>Issue</th><th>OWASP</th><th>CWE</th><th>Severity</th><th>Code</th></tr>\n")
            for fnd in group:
                f.write("<tr>")
                f.write(f"<td>{fnd.get('file','')}</td>")
                f.write(f"<td>{fnd.get('line','')}</td>")
                f.write(f"<td>{fnd.get('issue','')}</td>")
                f.write(f"<td>{fnd.get('owasp','')}</td>")
                f.write(f"<td>{fnd.get('cwe','')}</td>")
                f.write(f"<td>{fnd.get('severity','')}</td>")
                f.write(f"<td><code>{fnd.get('code','')}</code></td>")
                f.write("</tr>\n")

                if 'context' in fnd:
                    f.write("<tr><td colspan='7'>")
                    f.write("<details><summary>🔍 View Context</summary>\n<pre>")
                    for ctx in fnd['context']:
                        line = ctx.get("code", "").rstrip()
                        number = ctx.get("number", "")
                        highlight = 'highlight' if ctx.get("highlight") else ''
                        f.write(f"<div class='context-line {highlight}'><strong>{str(number).rjust(3)}:</strong> {line}</div>\n")
                    f.write("</pre></details>")
                    f.write("</td></tr>\n")
            f.write("</table>\n")

        f.write("<h2>📄 Full Findings with Context</h2>\n")
        render_group("🔥 High Issues with Context", highs)
        render_group("⚠️ Medium Issues with Context", mediums)
        render_group("🟡 Low Issues with Context", lows)

        f.write("</body></html>")
    print(f"📄 HTML report saved to: {html_path}")

def main():
    print("🛡️ Perl SAST – Full Report Mode")

    code_dir = ask_code_directory()
    report_name = ask_report_name()

    findings = run_scan(code_dir)
    if findings is None:
        return

    os.makedirs("json_results", exist_ok=True)
    os.makedirs("output", exist_ok=True)

    json_path = os.path.join("json_results", f"{report_name}.json")
    html_path = os.path.join("output", f"{report_name}.html")

    save_json(findings, json_path)
    save_html(findings, html_path)

    print("\n✅ Done! You can open the HTML file in your browser.")

if __name__ == "__main__":
    main()

