#!/bin/bash

# ==============================================================================
# run_all_scans.sh — IDs, per-file counts, GRAND TOTALS, and TOP 5 FILES
# ==============================================================================

echo "Please enter the path to the directory you want to scan (e.g., Testing/):"
read -r TARGET_DIR

if [ -z "$TARGET_DIR" ]; then
  echo "Error: No directory provided. Exiting."
  exit 1
fi

if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Directory '$TARGET_DIR' not found or is not a directory."
  exit 1
fi

run_section () {
  local file="$1"
  local theme="$2"
  local label="$3"
  local cat_id="$4"
  local count_var="$5"

  echo "--- [ $label ] ---"
  local out
  out=$(PERL5LIB=$PWD perlcritic --theme "$theme" "$file" 2>&1)

  if [ -n "$out" ]; then
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      echo "[$cat_id] $line"
    done <<< "$out"
  fi
  echo ""

  local count
  count=$(printf "%s\n" "$out" | sed '/^[[:space:]]*$/d' | grep -v 'source OK' | wc -l)
  eval "$count_var=$count"
}

mapfile -d '' FILES < <(find "$TARGET_DIR" -type f -name "*.pl" -print0)
if [ "${#FILES[@]}" -eq 0 ]; then
  echo "No .pl files found in '$TARGET_DIR'."
  exit 0
fi

GRAND_HIGH=0
GRAND_MED=0
GRAND_LOW=0
GRAND_INFO=0

# Track per-file totals for ranking
declare -A FILE_TOTALS

for file in "${FILES[@]}"; do
  echo "=============================================================================="
  echo "Scanning File: $file"
  echo "=============================================================================="
  echo ""

  HIGH_COUNT=0
  MED_COUNT=0
  LOW_COUNT=0
  INFO_COUNT=0

  run_section "$file" "perl_high_risk"             "High Risk Issues"         "HIGH-001" "HIGH_COUNT"
  run_section "$file" "perl_medium_threat"         "Medium Threat Issues"     "MED-001"  "MED_COUNT"
  run_section "$file" "perl_low_visibility"        "Low Visibility Issues"    "LOW-001"  "LOW_COUNT"
  run_section "$file" "perl_best_coding_practice"  "Best Coding Practices"    "INFO-001" "INFO_COUNT"

  echo "______________________________________________________________________________"
  echo ""
  echo ">>> Summary for: $file"
  echo "    [HIGH-001] High:   $HIGH_COUNT"
  echo "    [MED-001 ] Medium: $MED_COUNT"
  echo "    [LOW-001 ] Low:    $LOW_COUNT"
  echo "    [INFO-001] Info:   $INFO_COUNT"
  echo ""
  echo ""

  GRAND_HIGH=$((GRAND_HIGH + HIGH_COUNT))
  GRAND_MED=$((GRAND_MED + MED_COUNT))
  GRAND_LOW=$((GRAND_LOW + LOW_COUNT))
  GRAND_INFO=$((GRAND_INFO + INFO_COUNT))

  TOTAL_FOR_FILE=$((HIGH_COUNT + MED_COUNT + LOW_COUNT + INFO_COUNT))
  FILE_TOTALS["$file"]=$TOTAL_FOR_FILE
done

echo "=============================================================================="
echo "GRAND TOTALS (all scanned files)"
echo "=============================================================================="
echo "    [HIGH-001] High:   $GRAND_HIGH"
echo "    [MED-001 ] Medium: $GRAND_MED"
echo "    [LOW-001 ] Low:    $GRAND_LOW"
echo "    [INFO-001] Info:   $GRAND_INFO"
echo ""

# --- Top 5 most vulnerable files (by total issues) ---
# Build "count<TAB>file" lines, sort desc by count, take top 5
RANKED=$(for f in "${!FILE_TOTALS[@]}"; do
  printf "%s\t%s\n" "${FILE_TOTALS[$f]}" "$f"
done | sort -nr -k1,1 | head -5)

echo "=============================================================================="
echo "TOP 5 MOST VULNERABLE FILES (total issues)"
echo "=============================================================================="
i=1
while IFS=$'\t' read -r count path; do
  [[ -z "$count" || -z "$path" ]] && continue
  printf " %d) %s - %s issues\n" "$i" "$path" "$count"
  i=$((i+1))
done <<< "$RANKED"

echo ""
echo "All scans complete."

