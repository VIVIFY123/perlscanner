#!/usr/bin/perl
use strict;
use warnings;

# --- Low Severity: Compromised CDN (simulate bad URL usage) ---
my $cdn_url = "http://compromised-cdn.example.com/lib.js";

# --- Deprecated Functions or Properties ---
# Using 'substr' with 3 args is not deprecated, so let's simulate a deprecated function with 'each' on array ref (deprecated in some versions)
my @arr = (1,2,3);
my $deprecated_func = each \@arr; # deprecated usage in some contexts

# --- Deprecated Modules or Libraries ---
use CGI::Carp;  # deprecated module example

# --- Improper Filtering of Special Elements ---
my $special_input = "<script>alert('xss')</script>";

# --- Information Exposure Through an Error Message ---
eval { die "Sensitive info: password=1234"; };
print $@ if $@;  # printing raw error exposes info

# --- Log Forging ---
my $user_input = "user\nInjected log entry";
print "Log entry: $user_input\n";  # no sanitization of newline

# --- Not Checking Regular Expressions Results ---
my $data = "abc";
$data =~ /(d)/;  # regex without checking result

# --- Overloading Reserved Keywords or Subroutines ---
sub print {  # overriding built-in print
    return;
}

print("This won't print\n");

# --- Permissive Regular Expression ---
my $input = "anything";
if ($input =~ /.*/ ) {  # too permissive regex
    # do something
}

# --- Prohibit Indirect Object Call Syntax ---
my $obj = "SomeClass";
my $method = "new";
$obj->$method();  # indirect object syntax

# --- Signifying Inheritance At Runtime ---
my $class = "SomeBaseClass";
eval "package Child; use base '$class';";

# --- Unchecked Return Value ---
open(FILE, "nonexistentfile.txt");  # no check of open success

# --- Use of Broken or Risky Cryptographic Algorithm ---
use Digest::MD5 qw(md5_hex);
my $hash = md5_hex("data");  # MD5 is risky

# --- Variables Outside The Scope of a Regex ---
my $outside_var;
if ("test" =~ /(t)(e)(s)(t)/) {
    $outside_var = $1;
}
print "$outside_var\n";

# --- Information Severity: Empty Methods ---
sub empty_method {}

# --- Hardcoded Absolute Path ---
my $abs_path = "/etc/passwd";

# --- Prepending Leading Zeroes to Integer Literals ---
my $num = 0123;  # octal literal with leading zero

# --- Reusing Variable Names In Subscopes ---
my $var = 1;
{
    my $var = 2;
    print "$var\n";
}

# --- Using Perl4 Package Names ---
package Foo::Bar;
sub dummy {}

# --- Using Subroutine Prototypes ---
sub foo($$) { return $_[0] + $_[1]; }
print foo(2,3), "\n";
