#!/usr/bin/perl
use strict;
use warnings;
use CGI;
use LWP::UserAgent;
use XML::Simple;

# 🐞 CSRF - No token validation
if ($ENV{'REQUEST_METHOD'} eq 'POST') {
    my $password = param('password');
    system("echo $password >> /tmp/secrets.txt");
}

# 🐞 Improper Restriction of XXE
my $xml = '<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]><foo>&xxe;</foo>';
my $data = XMLin($xml);

# 🐞 Parameter Tampering
my $amount = param('amount');
if ($amount > 1000) {
    print "Transaction Approved\n";
}



# ✅ $ARGV[0]
if ($ARGV[0] eq 'admin') { ... }

# ✅ $ENV
if ($ENV{'USER_ROLE'} eq 'admin') { ... }

# ✅ CGI param
if ($param{'debug'} eq '1') { ... }

# ✅ JSON
if ($json->{'debug'}) { ... }

# ✅ $req->param
if ($req->param('delete') eq '1') { ... }




# 🐞 Path Traversal
my $file = param('file');
open(my $fh, '<', "/var/www/data/$file");
print while <$fh>;
close $fh;

# 🐞 Privacy Violation
my $ssn = $ENV{'HTTP_X_USER_SSN'};
print "Your SSN is: $ssn\n";

# 🐞 Stored Code Injection
my $custom_code = param('payload');
eval $custom_code;

# 🐞 Stored Command Injection
my $cmd = param('run');
system("ping -c 4 $cmd");

# 🐞 Stored LDAP Injection
my $user = param('user');
my $filter = "(uid=$user)";
# (Pretend LDAP search here)

# 🐞 Stored Path Traversal
my $path = param('dir');
do "$path/config.pl";

# 🐞 Uncontrolled Format String
my $user_input = param('format');
printf($user_input);

# 🐞 Uncontrolled Memory Allocation
my $size = param('size');
my @array = (0) x $size;

# 🐞 Unprotected Transport of Credentials
my $ua = LWP::UserAgent->new;
my $res = $ua->post('http://insecure.com/login', {
    user => 'admin',
    pass => 'admin123'
});

# 🐞 Use of Hardcoded Password
my $hardcoded = 'SuperSecret123!';
print "Using password: $hardcoded\n";

# 🐞 Use of two-argument open()
my $file2 = param('log');
open FH, "$file2";  # 2-arg open

# CWE-400: DoS by Sleep
my $delay = param('delay');
sleep($delay);  # This must trigger the DoS_by_Sleep rule


