use strict;
use warnings;
use DBI;

# 1. SQL Injection (CWE-89)
my $user_input = <STDIN>;
my $sql = "SELECT * FROM users WHERE name = '$user_input'";
my $dbh = DBI->connect("dbi:mysql:database=test", "root", "");
my $sth = $dbh->prepare($sql);
$sth->execute();

# 2. Second Order SQL Injection (CWE-89)
my $stored_input = $user_input;
my $sql2 = "SELECT * FROM accounts WHERE id = '$stored_input'";
my $sth2 = $dbh->prepare($sql2);
$sth2->execute();

# ✅ Connection String Injection (CWE-99)
my $dbname = <STDIN>;
my $dbh_injected = DBI->connect("dbi:mysql:dbname=$dbname", "root", "");  # Should be flagged

# 3. Dangerous File Inclusion (CWE-829)
my $file_to_open = <STDIN>;
open(my $fh, "<", $file_to_open) or die "Cannot open file: $!";

# 4. Resource Injection (CWE-99)
my $resource = <STDIN>;
open(my $rfh, "$resource") or die "Cannot open resource: $!";

# 5. Code Injection (CWE-94)
my $evil_code = <STDIN>;
eval $evil_code;

# 6. Command Injection (CWE-77)
my $cmd = <STDIN>;
system("ls $cmd");

# 7. Stored Command Injection (CWE-77)
my $stored_cmd = $cmd;
system("ping $stored_cmd");

# 8. LDAP Injection (CWE-90)
use Net::LDAP;
my $ldap_user = <STDIN>;
my $ldap = Net::LDAP->new("ldap://$ldap_user");
$ldap->search(filter => "(&(uid=$ldap_user))");

# 9. Reflected XSS (CWE-79)
my $reflected = <STDIN>;
print "Welcome $reflected\n";

# 10. Stored XSS (CWE-79)
my $stored = $reflected;
print "Your last message: $stored\n";

