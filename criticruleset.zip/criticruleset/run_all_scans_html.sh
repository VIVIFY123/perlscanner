#!/bin/bash

# ==============================================================================
# run_all_scans_html.sh — same logic/IDs as v2, but writes full output to HTML
# Prompts:
#   1) Folder to scan
#   2) Output folder for the HTML file (created if missing)
#   3) Base name of the HTML file (no need to add .html)
# ==============================================================================

# ----- Prompts -----
echo "Enter the path to the directory you want to scan (e.g., Testing/):"
read -r TARGET_DIR

echo "Enter the folder where the HTML should be saved (e.g., Reports/):"
read -r OUTPUT_DIR

echo "Enter the name of the HTML file (without .html):"
read -r HTML_BASE

# ----- Validate inputs -----
if [ -z "$TARGET_DIR" ]; then
  echo "Error: No scan directory provided. Exiting."
  exit 1
fi
if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Directory '$TARGET_DIR' not found or is not a directory."
  exit 1
fi
if [ -z "$OUTPUT_DIR" ]; then
  echo "Error: No output directory provided. Exiting."
  exit 1
fi
if [ -z "$HTML_BASE" ]; then
  echo "Error: No HTML file name provided. Exiting."
  exit 1
fi

mkdir -p "$OUTPUT_DIR"
OUTPUT_PATH="$OUTPUT_DIR/$HTML_BASE.html"

# ----- Accumulators -----
TEXT_LOG=""   # we'll mirror the CLI text here, then embed it in <pre> in HTML

# helper to append a line to TEXT_LOG (preserving exact layout)
append() {
  TEXT_LOG+="$1"$'\n'
}

# ----- scan section (same logic/IDs) -----
run_section () {
  local file="$1"
  local theme="$2"
  local label="$3"
  local cat_id="$4"
  local count_var="$5"

  append "--- [ $label ] ---"
  local out
  out=$(PERL5LIB=$PWD perlcritic --theme "$theme" "$file" 2>&1)

  if [ -n "$out" ]; then
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      append "[$cat_id] $line"
    done <<< "$out"
  fi
  append ""

  # count only real findings (exclude blanks and "source OK")
  local count
  count=$(printf "%s\n" "$out" | sed '/^[[:space:]]*$/d' | grep -v 'source OK' | wc -l)
  eval "$count_var=$count"
}

# ----- collect files (no subshell to keep totals) -----
mapfile -d '' FILES < <(find "$TARGET_DIR" -type f -name "*.pl" -print0)
if [ "${#FILES[@]}" -eq 0 ]; then
  echo "No .pl files found in '$TARGET_DIR'."
  exit 0
fi

# ----- grand totals -----
GRAND_HIGH=0
GRAND_MED=0
GRAND_LOW=0
GRAND_INFO=0

# per-file totals for ranking
declare -A FILE_TOTALS

# ----- header (like CLI but going to TEXT_LOG) -----
# We’ll keep the exact visual formatting you like and push into HTML <pre>.
for file in "${FILES[@]}"; do
  append "=============================================================================="
  append "Scanning File: $file"
  append "=============================================================================="
  append ""

  HIGH_COUNT=0
  MED_COUNT=0
  LOW_COUNT=0
  INFO_COUNT=0

  run_section "$file" "perl_high_risk"             "High Risk Issues"         "HIGH-001" "HIGH_COUNT"
  run_section "$file" "perl_medium_threat"         "Medium Threat Issues"     "MED-001"  "MED_COUNT"
  run_section "$file" "perl_low_visibility"        "Low Visibility Issues"    "LOW-001"  "LOW_COUNT"
  run_section "$file" "perl_best_coding_practice"  "Best Coding Practices"    "INFO-001" "INFO_COUNT"

  append "______________________________________________________________________________"
  append ""
  append ">>> Summary for: $file"
  append "    [HIGH-001] High:   $HIGH_COUNT"
  append "    [MED-001 ] Medium: $MED_COUNT"
  append "    [LOW-001 ] Low:    $LOW_COUNT"
  append "    [INFO-001] Info:   $INFO_COUNT"
  append ""
  append ""

  GRAND_HIGH=$((GRAND_HIGH + HIGH_COUNT))
  GRAND_MED=$((GRAND_MED + MED_COUNT))
  GRAND_LOW=$((GRAND_LOW + LOW_COUNT))
  GRAND_INFO=$((GRAND_INFO + INFO_COUNT))

  TOTAL_FOR_FILE=$((HIGH_COUNT + MED_COUNT + LOW_COUNT + INFO_COUNT))
  FILE_TOTALS["$file"]=$TOTAL_FOR_FILE
done

append "=============================================================================="
append "GRAND TOTALS (all scanned files)"
append "=============================================================================="
append "    [HIGH-001] High:   $GRAND_HIGH"
append "    [MED-001 ] Medium: $GRAND_MED"
append "    [LOW-001 ] Low:    $GRAND_LOW"
append "    [INFO-001] Info:   $GRAND_INFO"
append ""

# ----- Top 5 ranking (same as CLI version) -----
RANKED=$(for f in "${!FILE_TOTALS[@]}"; do
  printf "%s\t%s\n" "${FILE_TOTALS[$f]}" "$f"
done | sort -nr -k1,1 | head -5)

append "=============================================================================="
append "TOP 5 MOST VULNERABLE FILES (total issues)"
append "=============================================================================="
i=1
while IFS=$'\t' read -r count path; do
  [[ -z "$count" || -z "$path" ]] && continue
  append " $i) $path - $count issues"
  i=$((i+1))
done <<< "$RANKED"
append ""
append "All scans complete."

# ----- Write HTML file -----
# Escape &, <, > so the text shows exactly as-is inside <pre>
ESCAPED=$(printf "%s" "$TEXT_LOG" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g')

cat > "$OUTPUT_PATH" <<EOF
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Perl SAST Ultra – Scan Report</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin: 24px; background:#0b0e14; color:#e6e6e6; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
    .wrap { max-width: 1200px; margin: 0 auto; }
    h1 { font-size: 20px; margin: 0 0 12px; color:#9cdcfe; }
    .meta { color:#a0a0a0; font-size:12px; margin-bottom:16px; }
    pre { white-space: pre-wrap; word-wrap: break-word; background:#111422; padding:16px; border-radius:10px; border:1px solid #1e2336; line-height:1.4; }
    a { color:#9cdcfe; text-decoration:none; }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Perl SAST Ultra — Scan Report</h1>
    <div class="meta">Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')</div>
    <pre>$ESCAPED</pre>
  </div>
</body>
</html>
EOF

echo "HTML report written to: $OUTPUT_PATH"

