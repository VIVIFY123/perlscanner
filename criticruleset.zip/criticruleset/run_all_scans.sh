#!/bin/bash

# ==============================================================================
# run_all_scans.sh
#
# This script prompts the user for a directory, then recursively finds all
# Perl files (*.pl) within it and runs four separate Perl::Critic scans
# against each file, one for each custom theme.
#
# The output for each file is clearly separated by a header and a footer.
#
# Usage:
#   1. Save this file as 'run_all_scans.sh' in your 'criticruleset' directory.
#   2. Make it executable: chmod +x run_all_scans.sh
#   3. Run it from the 'criticruleset' directory: ./run_all_scans.sh
# ==============================================================================

# --- Prompt the user for the directory to scan ---
echo "Please enter the path to the directory you want to scan (e.g., Testing/):"
read -r TARGET_DIR

# --- Validate the input ---
# Check if the user provided any input
if [ -z "$TARGET_DIR" ]; then
    echo "Error: No directory provided. Exiting."
    exit 1
fi

# Check if the provided path is actually a directory
if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Directory '$TARGET_DIR' not found or is not a directory."
  exit 1
fi

# --- Main scan loop ---
# Find all files ending in .pl within the user-provided directory and loop through them.
find "$TARGET_DIR" -type f -name "*.pl" -print0 | while IFS= read -r -d '' file; do

  # --- Print a clear header for the file being scanned ---
  echo "=============================================================================="
  echo "Scanning File: $file"
  echo "=============================================================================="
  echo ""

  # --- Run the 4 separate theme scans ---
  echo "--- [ High Risk Issues ] ---"
  PERL5LIB=$PWD perlcritic --theme perl_high_risk "$file"
  echo ""

  echo "--- [ Medium Threat Issues ] ---"
  PERL5LIB=$PWD perlcritic --theme perl_medium_threat "$file"
  echo ""

  echo "--- [ Low Visibility Issues ] ---"
  PERL5LIB=$PWD perlcritic --theme perl_low_visibility "$file"
  echo ""

  echo "--- [ Best Coding Practices ] ---"
  PERL5LIB=$PWD perlcritic --theme perl_best_coding_practice "$file"
  echo ""

  # --- Print a separator for readability ---
  echo "______________________________________________________________________________"
  echo ""
  echo ""

done

echo "All scans complete."

