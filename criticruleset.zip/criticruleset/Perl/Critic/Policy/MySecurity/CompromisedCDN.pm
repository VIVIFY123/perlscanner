package Perl::Critic::Policy::MySecurity::CompromisedCDN;

use strict;
use warnings;
use base 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC  => q{Possible use of compromised or non-secure CDN link};
Readonly::Scalar my $EXPL  => q{CDNs should use HTTPS and come from trusted, versioned sources};

sub default_severity { return $Perl::Critic::Utils::Severity::LOWEST; }   # 0
sub default_themes   { return qw(perl_low_visibility); }
sub applies_to       { return 'PPI::Token::Quote'; }

sub violates {
    my ($self, $elem, undef) = @_;
    my $content = $elem->content;

    if ($content =~ m{http://.*(cdn|cloudflare|googleapis|jsdelivr|cdnjs|raw\.githubusercontent)\.com}i ||
        $content =~ m{https://.*(raw\.githubusercontent|cdn\.unknown)\.com}i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
