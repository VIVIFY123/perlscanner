package Perl::Critic::Policy::MySecurity::DangerousFileInclusion;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-829: Dangerous File Inclusion
Readonly::Scalar my $DESC => 'Possible Dangerous File Inclusion (CWE-829)';
Readonly::Scalar my $EXPL => 'Avoid including or opening files based on dynamic input.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 } # High
sub default_themes   { return qw(security perl_high_risk dangerous file_inclusion) }

sub violates {
    my ($self, $elem, $doc) = @_;
    return unless $elem->isa('PPI::Token::Word');

    my $function = $elem->content;

    # Target functions
    my @dangerous = qw(require do open read readline slurp);
    return unless grep { $_ eq $function } @dangerous;

    my $sibling = $elem->snext_sibling;
    return unless $sibling;

    # Check arguments for dynamic input
    if ($sibling->isa('PPI::Structure::List')) {
        my @tokens = $sibling->tokens;
        foreach my $token (@tokens) {
            if (
                ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$/) ||
                ($token->isa('PPI::Token::Quote') && $token->content =~ /\$|\./) ||
                ($token->isa('PPI::Token::Word') && $token->content =~ /^ENV$/)
            ) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }
    }

    return;
}

1;
