package Perl::Critic::Policy::MySecurity::Empty_Methods;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;
use PPI::Token::Word;

Readonly::Scalar my $DESC => 'Empty Methods (CWE-398)';
Readonly::Scalar my $EXPL => 'Avoid having subroutines or methods with no body — it indicates incomplete code or poor maintainability.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_best_coding_practice) }
sub applies_to       { return 'PPI::Statement::Sub' }

sub violates {
    my ($self, $elem, undef) = @_;

    my $block = $elem->block;
    return if !$block;

    my @children = $block->schildren;
    return if @children > 0;  # Method has content

    return $self->violation($DESC, $EXPL, $elem);
}

1;
