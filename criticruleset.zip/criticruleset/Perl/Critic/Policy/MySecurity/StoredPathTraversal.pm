package Perl::Critic::Policy::MySecurity::StoredPathTraversal;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Stored Path Traversal (CWE-22)';
Readonly::Scalar my $EXPL => 'User-controlled input is stored and later used in file paths, which can allow unauthorized file access. Validate input or use safe file access patterns.';

sub applies_to { 'PPI::Statement::Variable', 'PPI::Statement' }

sub default_severity { 3 }
sub default_themes   { qw(security perl_medium_threat stored_path_traversal) }

my %user_controlled_vars;

sub violates {
    my ($self, $elem, $doc) = @_;

    # Track user-controlled variables from assignments to param(...)
    if ($elem->isa('PPI::Statement::Variable')) {
        my @tokens = $elem->tokens;
        my ($var_name, $rhs_is_param);

        for my $i (0 .. $#tokens) {
            my $tok = $tokens[$i];
            if ($tok->isa('PPI::Token::Symbol')) {
                $var_name = $tok->content;
            }
            if ($tok->isa('PPI::Token::Word') && $tok->content eq 'param') {
                $rhs_is_param = 1;
            }
        }
        if ($rhs_is_param && $var_name) {
            $user_controlled_vars{$var_name} = 1;
            return; # Just record, no violation yet
        }
        return;
    }

    # Detect usage of user-controlled vars in file path ops
    if ($elem->isa('PPI::Statement')) {
        my @tokens = $elem->tokens;
        return unless @tokens;

        # Look for 'do', 'open', 'sysopen', 'read', 'write', 'unlink', 'opendir', 'readdir', 'copy', 'move', 'rename'
        my $first_tok = $tokens[0];
        if ($first_tok->isa('PPI::Token::Word')) {
            my $func = $first_tok->content;
            return unless $func =~ /^(do|open|sysopen|read|write|unlink|opendir|readdir|copy|move|rename)$/;

            # Look for double-quoted string in tokens (with interpolation)
            for my $tok (@tokens) {
                if ($tok->isa('PPI::Token::Quote::Double')) {
                    my $content = $tok->content;

                    # Check if content interpolates any user-controlled var
                    for my $uc_var (keys %user_controlled_vars) {
                        # We check for presence of variable name without '$' (interpolation strips it in strings)
                        my $var_no_dollar = $uc_var;
                        $var_no_dollar =~ s/^\$//;
                        if ($content =~ /\Q$var_no_dollar\E/) {
                            return $self->violation($DESC, $EXPL, $elem);
                        }
                    }
                }
            }
        }
    }

    return;
}

1;

