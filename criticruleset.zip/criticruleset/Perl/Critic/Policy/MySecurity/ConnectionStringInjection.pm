package Perl::Critic::Policy::MySecurity::ConnectionStringInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-99: Connection String Injection
Readonly::Scalar my $DESC => 'Possible Connection String Injection (CWE-99)';
Readonly::Scalar my $EXPL => 'Avoid using dynamic input in DBI->connect() connection strings.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk db_connection connection_string_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;
    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content eq 'connect';

    my $prev = $elem->sprevious_sibling;
    return unless $prev && $prev->isa('PPI::Token::Operator') && $prev->content eq '->';

    my $obj = $prev->sprevious_sibling;
    return unless $obj && $obj->isa('PPI::Token::Word') && $obj->content eq 'DBI';

    my $args = $elem->snext_sibling;
    return unless $args && $args->isa('PPI::Structure::List');

    my @tokens = $args->tokens;

    foreach my $token (@tokens) {
        if (
            ($token->isa('PPI::Token::Quote') && $token->content =~ /\$|\./) ||
            ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$/) ||
            ($token->isa('PPI::Token::QuoteLike::Words') && $token->content =~ /\$|\./)
        ) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;

