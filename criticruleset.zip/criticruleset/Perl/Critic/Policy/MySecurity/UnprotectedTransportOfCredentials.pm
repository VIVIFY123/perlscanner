package Perl::Critic::Policy::MySecurity::UnprotectedTransportOfCredentials;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Unprotected Transport of Credentials (CWE-523)';
Readonly::Scalar my $EXPL => 'Credentials transmitted over non-HTTPS connection. Use secure transport for authentication.';

sub applies_to {
    return 'PPI::Token::Quote';
}

sub default_severity { return 3 }
sub default_themes   { return qw(security perl_medium_threat unprotected_transport_of_credentials) }

sub violates {
    my ($self, $elem, undef) = @_;

    return unless $elem->isa('PPI::Token::Quote');

    my $content = $elem->string;

    # Only continue if this quoted string looks like a URL starting with http://
    return unless ($content =~ m{^http://}i);

    # Find parent statement (e.g. method call)
    my $statement = $elem->parent;
    while ($statement && !$statement->isa('PPI::Statement')) {
        $statement = $statement->parent;
    }
    return unless $statement;

    # Look for hash constructor ( { ... } ) which is the 2nd argument
    my $found_credentials = 0;

    # Search children for hash constructor
    my @children = $statement->children;

    foreach my $child (@children) {
        next unless ref($child);
        if ($child->isa('PPI::Structure::Constructor')) {
            # Inspect tokens inside constructor for credential keys
            my @tokens = $child->tokens;
            foreach my $tok (@tokens) {
                if ($tok->isa('PPI::Token::Word')) {
                    my $word = $tok->content;
                    if ($word =~ /^(user(name)?|pass(word)?|pwd|token|auth|apikey|credential(s)?)$/i) {
                        $found_credentials = 1;
                        last;
                    }
                }
            }
            last if $found_credentials;
        }
    }

    if ($found_credentials) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;

