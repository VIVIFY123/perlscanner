package Perl::Critic::Policy::MySecurity::LDAPInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-90: LDAP Injection
Readonly::Scalar my $DESC => 'Possible LDAP Injection (CWE-90)';
Readonly::Scalar my $EXPL => 'Avoid building LDAP filters or connections with dynamic input. Use proper escaping or parameterization.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk ldap_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $function = $elem->content;

    # -- CASE 1: Net::LDAP->new("ldap://$host")
    if ($function eq 'new') {
        my $prev = $elem->sprevious_sibling;
        return unless $prev && $prev->isa('PPI::Token::Operator') && $prev->content eq '->';

        my $obj = $prev->sprevious_sibling;
        return unless $obj && $obj->isa('PPI::Token::Word') && $obj->content =~ /Net::LDAP/i;

        my $args = $elem->snext_sibling;
        return unless $args && $args->isa('PPI::Structure::List');

        foreach my $token ($args->tokens) {
            if (
                ($token->isa('PPI::Token::Quote') && $token->content =~ /\$\w+/) ||   # interpolated
                ($token->isa('PPI::Token::Operator') && $token->content eq '.')       # dot concat
            ) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }
    }

    # -- CASE 2: search(filter => "(&(uid=$input))") or "uid=" . $input
    if ($function eq 'search') {
        my $sibling = $elem->snext_sibling;
        return unless $sibling && $sibling->isa('PPI::Structure::List');

        my @tokens = $sibling->tokens;
        my $is_filter_context = 0;
        for (my $i = 0; $i < @tokens; $i++) {
            my $t = $tokens[$i];

            if ($t->isa('PPI::Token::Word') && $t->content eq 'filter') {
                $is_filter_context = 1;
            }

            if ($is_filter_context) {
                if (
                    ($t->isa('PPI::Token::Quote') && $t->content =~ /\$\w+/) ||   # "$user"
                    ($t->isa('PPI::Token::Operator') && $t->content eq '.')       # "uid=" . $user
                ) {
                    return $self->violation($DESC, $EXPL, $elem);
                }
            }
        }
    }

    return;
}

1;

