package Perl::Critic::Policy::MySecurity::Deprecated_Modules_or_Libraries;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Use of deprecated Perl module or library (CWE-477)';
Readonly::Scalar my $EXPL => 'Avoid using deprecated modules or libraries. These may be removed in future versions or pose security or maintenance risks.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 1 }

sub default_themes   { return qw(perl_low_visibility); }

my @DEPRECATED_MODULES = qw(
    CGI
    Shell
    Switch
    Net::FTP
    Net::Telnet
    Socket6
    Class::ISA
    Devel::DProf
    Pod::Plainer
);

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $word = $elem->content;

    foreach my $mod (@DEPRECATED_MODULES) {
        return $self->violation($DESC, $EXPL, $elem) if $word eq $mod;
    }

    return;
}

1;
