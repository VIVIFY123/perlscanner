package Perl::Critic::Policy::MySecurity::StoredCodeInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-94: Code Injection via dynamic execution
Readonly::Scalar my $DESC => 'Possible Stored Code Injection (CWE-94)';
Readonly::Scalar my $EXPL => 'Avoid using eval, do, or require with variables that may be influenced by user input.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat stored_code_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(eval|do|require)$/;

    my $sibling = $elem->snext_sibling;
    return unless $sibling;

    # Accept both quoted and unquoted expressions
    my $content = $sibling->content;
    if ($content =~ /\$?(code|cmd|input|user|param|expression|payload)/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
