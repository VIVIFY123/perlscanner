package Perl::Critic::Policy::MySecurity::DeprecatedFunctions_or_Properties;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Use of deprecated Perl function or module (CWE-477)';
Readonly::Scalar my $EXPL => 'Avoid using deprecated functions or modules. These may be removed in future versions or pose security risks.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 1 }

sub default_themes   { return qw(perl_low_visibility); }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $function = $elem->content;

    my @bad = qw(
        defined
        setlocale
        dump
        goto
        reset
        study
        CGI
        Shell
        Switch
    );

    foreach my $deprecated (@bad) {
        if (lc($function) eq lc($deprecated)) {

            # Special handling for defined(@array)
            if ($function eq 'defined') {
                my $next = $elem->snext_sibling;
                if ($next && $next->isa('PPI::Structure::List')) {
                    my $inner = $next->schild(0);
                    if ($inner && $inner->isa('PPI::Token::Symbol') && $inner->content =~ /^\@/) {
                        return $self->violation($DESC, $EXPL, $elem);
                    }
                    return; # defined($scalar) is OK
                }
            }

            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
