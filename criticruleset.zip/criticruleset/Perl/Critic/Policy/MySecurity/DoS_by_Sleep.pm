package Perl::Critic::Policy::MySecurity::DoS_by_Sleep;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Possible Denial of Service via sleep() (CWE-400)';
Readonly::Scalar my $EXPL     => 'Use of sleep() with uncontrolled input can cause denial of service. Avoid sleep() with untrusted values or use timeouts.';
Readonly::Scalar my $SEVERITY => 3;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_medium_threat',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_medium_threat) }
sub applies_to       { return 'PPI::Token::Word' }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content eq 'sleep';

    # Ensure it's a sleep($something)
    my $parent = $elem->snext_sibling;
    return unless $parent && $parent->isa('PPI::Structure::List');

    my $arg_tokens = $parent->find('PPI::Token::Symbol');
    return unless $arg_tokens && @$arg_tokens == 1;

    my $var = $arg_tokens->[0]->content;  # e.g. $delay

    # Now scan backward for a taint source
    my $stmts = $doc->find('PPI::Statement::Variable') || [];
    foreach my $stmt (reverse @$stmts) {
        next unless $stmt->content =~ /\Q$var\E/;
        return $self->violation($DESC, $EXPL, $elem)
            if $stmt->content =~ /\bparam\s*\(/;
    }

    return;
}

1;

