package Perl::Critic::Policy::MySecurity::StoredLDAPInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Stored LDAP Injection (CWE-90)';
Readonly::Scalar my $EXPL => 'User input is embedded unsafely into LDAP filter strings. Validate or sanitize input before use.';

# Package-level hash to track user-controlled variables across violations
my %user_controlled_vars;

sub applies_to { 'PPI::Statement::Variable' }

sub default_severity { 3 }
sub default_themes { qw(security perl_medium_threat stored_ldap_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    my @tokens = $elem->tokens;

    my $var_name;
    my $rhs_string = '';
    my $rhs_is_param = 0;

    # Find variable name and RHS tokens
    for my $i (0 .. $#tokens) {
        my $tok = $tokens[$i];

        # Get variable name (LHS)
        if ($tok->isa('PPI::Token::Symbol')) {
            $var_name = $tok->content;
        }

        # Check if RHS contains param() call
        if ($tok->isa('PPI::Token::Word') && $tok->content eq 'param') {
            $rhs_is_param = 1;
        }

        # Capture double quoted string on RHS for interpolation check
        if ($tok->isa('PPI::Token::Quote::Double')) {
            $rhs_string = $tok->content;
        }
    }

    # If variable assigned from param(), mark it as user-controlled
    if ($rhs_is_param && defined $var_name) {
        $user_controlled_vars{$var_name} = 1;
        return;  # no violation here, just track for later
    }

    # Check if RHS string interpolates any user-controlled variable
    for my $uc_var (keys %user_controlled_vars) {
        # Escape $ in variable name for regex (e.g. $user)
        my $escaped_var = quotemeta($uc_var);

        if ($rhs_string =~ /$escaped_var/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;

