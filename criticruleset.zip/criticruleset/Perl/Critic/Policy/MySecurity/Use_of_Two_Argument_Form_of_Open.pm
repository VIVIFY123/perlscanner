package Perl::Critic::Policy::MySecurity::Use_of_Two_Argument_Form_of_Open;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Use of Two-Argument Form of open (CWE-77)';
Readonly::Scalar my $EXPL     => 'The two-argument form of open can allow command injection if untrusted input is passed. Use the three-argument form to separate mode from filename.';
Readonly::Scalar my $SEVERITY => 3;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_medium_threat',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_medium_threat) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;

    return unless $elem->isa('PPI::Statement');
    my @tokens = $elem->schildren;
    return unless @tokens;

    for my $i (0 .. $#tokens - 1) {
        next unless $tokens[$i]->isa('PPI::Token::Word');
        next unless $tokens[$i]->content eq 'open';

        # Count commas directly in this statement
        my $comma_count = grep { $_->isa('PPI::Token::Operator') && $_->content eq ',' } @tokens;

        # Trigger if and only if exactly 1 comma (i.e., 2-arg open)
        if ( $comma_count == 1 ) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
