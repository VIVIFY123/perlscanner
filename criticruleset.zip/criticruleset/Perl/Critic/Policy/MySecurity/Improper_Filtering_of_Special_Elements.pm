package Perl::Critic::Policy::MySecurity::Improper_Filtering_of_Special_Elements;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Improper Filtering of Special Elements (CWE-790)';
Readonly::Scalar my $EXPL => 'Unescaped or unfiltered user input sent to sinks like print, system, open, exec, or log output.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 1 }

sub default_themes   { return qw(perl_low_visibility); }

my @SINKS = qw(print system exec open warn die log_error write);

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $func = $elem->content;
    return unless grep { $_ eq $func } @SINKS;

    my $next = $elem->snext_sibling;
    return unless $next && $next->isa('PPI::Structure::List');

    my $found = $next->find_any(sub {
        my ($top, $child) = @_;
        return $child->isa('PPI::Token::Symbol') && $child->content =~ /^\$/;
    });

    if ($found) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
