package Perl::Critic::Policy::MySecurity::CodeInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-94: Code Injection
Readonly::Scalar my $DESC => 'Dynamic code execution detected (CWE-94)';
Readonly::Scalar my $EXPL => 'Avoid using eval, require, or do with dynamic input. Code injection risk.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }  # or 3, 2, etc depending on the policy
sub default_themes   { return qw(security perl_high_risk dangerous code_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;
    return unless $elem->isa('PPI::Token::Word');

    my $function = $elem->content;

    # Dangerous dynamic execution functions
    my @dangerous = qw(eval require do use);
    return unless grep { $_ eq $function } @dangerous;

    my $sibling = $elem->snext_sibling;
    return unless $sibling;

    # Handle: eval($input), eval("$input"), require "$var", do $file
    my @tokens = ();

    if ($sibling->isa('PPI::Structure::List')) {
        @tokens = $sibling->tokens;
    } else {
        @tokens = ($sibling);
    }

    foreach my $token (@tokens) {
        if (
            ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$/) ||
            ($token->isa('PPI::Token::Quote') && $token->content =~ /\$|\./) ||
            ($token->isa('PPI::Token::Word') && $token->content =~ /^ENV$/)
        ) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;

