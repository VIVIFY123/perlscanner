package Perl::Critic::Policy::MySecurity::SecondOrderSQLInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-89
Readonly::Scalar my $DESC => 'Possible Second-Order SQL Injection (CWE-89)';
Readonly::Scalar my $EXPL => 'User input stored and reused later in SQL queries. Validate and sanitize all input before DB usage.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk sql second_order_sql_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /\b(do|prepare|execute|select.*|fetch.*)\b/;

    my $sibling = $elem->snext_sibling;
    return unless $sibling && $sibling->isa('PPI::Structure::List');

    my @tokens = $sibling->tokens;
    foreach my $token (@tokens) {
        if ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$\w+$/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
        if ($token->isa('PPI::Token::Quote::Double') && $token->content =~ /\$\w+/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
