package Perl::Critic::Policy::MySecurity::Prohibit_Indirect_Object_Call_Syntax;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;
use PPI;

Readonly::Scalar my $DESC     => 'Prohibit Indirect Object Call Syntax (CWE-665)';
Readonly::Scalar my $EXPL     => 'Avoid using indirect object syntax like new Class instead of Class->new.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $code = $elem->content;

    # Look for "new ClassName" or any other indirect call
    if ($code =~ /\bnew\s+[A-Z]\w+\b/ && $code !~ /->new/) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
