package Perl::Critic::Policy::MySecurity::UncontrolledMemoryAllocation;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Uncontrolled Memory Allocation (CWE-789)';
Readonly::Scalar my $EXPL => 'Avoid allocating large memory structures using user input. This can lead to Denial of Service or crashes.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat uncontrolled_memory_allocation) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(x|y|z|my|push|map|chr|join|split|pack|substr|vec|splice|repeat)$/;

    my $parent = $elem->parent;
    my $line = $elem->location->[0];
    my $content = $parent->content;

    if ($content =~ /\$ARGV|\$_|\$input|\$user|param|readline/i && $content =~ /\d+|\[\]|\{\}/) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
