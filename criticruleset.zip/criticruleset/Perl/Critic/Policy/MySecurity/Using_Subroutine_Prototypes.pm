package Perl::Critic::Policy::MySecurity::Using_Subroutine_Prototypes;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Using Subroutine Prototypes (CWE-628)';
Readonly::Scalar my $EXPL     => 'Avoid using prototypes in subroutine declarations — they rarely work as expected and may mislead developers.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_best_coding_practice) }
sub applies_to           { return 'PPI::Statement::Sub' }

sub violates {
    my ($self, $elem, $doc) = @_;

    my $proto = $elem->prototype;
    if (defined $proto && $proto ne '') {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
