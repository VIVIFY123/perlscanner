package Perl::Critic::Policy::MySecurity::Unchecked_Return_Value;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Unchecked Return Value (CWE-252)';
Readonly::Scalar my $EXPL     => 'Always check return values of critical functions like system(), open(), close(), mkdir(), unlink().';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $code = $elem->content;

    # Only match if a critical function is called with NO return value check
    return if $code =~ /^\s*(?:if|unless|&&|\|\||\?\s*|!\s*)?\s*\(?[\$\w]+\s*=/; # return value used
    return if $code =~ /(?:die|croak|warn)/; # already handled

    if ($code =~ /\b(?:open|close|unlink|mkdir|system)\b\s*\(/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
