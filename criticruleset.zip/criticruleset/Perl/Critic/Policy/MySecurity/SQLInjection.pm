package Perl::Critic::Policy::MySecurity::SQLInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible SQL Injection (CWE-89)';
Readonly::Scalar my $EXPL => 'Avoid building SQL queries with user input. Use placeholders or sanitization.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk sql_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $content = $elem->content;
    return unless $content eq 'prepare' || $content eq 'do' || $content eq 'selectall_arrayref';

    my $sibling = $elem->snext_sibling;
    return unless $sibling && $sibling->isa('PPI::Structure::List');

    my @tokens = $sibling->tokens;

    foreach my $token (@tokens) {
        # Dynamic SQL string interpolation
        if ($token->isa('PPI::Token::Quote::Double') && $token->content =~ /\$\w+/) {
            return $self->violation($DESC, $EXPL, $elem);
        }

        # SQL string concatenation
        if ($token->isa('PPI::Token::Operator') && $token->content eq '.') {
            return $self->violation($DESC, $EXPL, $elem);
        }

        # Direct variable used as SQL
        if ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
