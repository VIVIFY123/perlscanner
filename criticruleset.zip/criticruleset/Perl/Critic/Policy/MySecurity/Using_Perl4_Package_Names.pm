package Perl::Critic::Policy::MySecurity::Using_Perl4_Package_Names;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Using Perl 4 Package Names (CWE-477)';
Readonly::Scalar my $EXPL     => 'Use double colons (::) instead of apostrophes (\') in package names.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_best_coding_practice) }
sub applies_to           { return 'PPI::Statement::Package' }

sub violates {
    my ($self, $elem, $doc) = @_;

    my $code = $elem->content;
    if ( $code =~ /\bpackage\s+\w+'[\w']+/ ) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
