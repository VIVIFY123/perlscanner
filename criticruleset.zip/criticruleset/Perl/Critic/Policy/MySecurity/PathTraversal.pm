package Perl::Critic::Policy::MySecurity::PathTraversal;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Path Traversal (CWE-22)';
Readonly::Scalar my $EXPL => 'User-controlled input used in file paths. This can allow unauthorized file access.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 } # Medium
sub default_themes   { return qw(security perl_medium_threat path_traversal) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(open|sysopen|unlink|rename|rmdir|mkdir|opendir|readlink)$/;

    my $sibling = $elem->snext_sibling;
    return unless $sibling;

    my $line = $elem->location->[0];

    # Search for tainted variable used in path
    while ($sibling) {
        if (
            ($sibling->isa('PPI::Token::Symbol') && $sibling->content =~ /\$ARGV|\$input|\$filename|\$file/) ||
            ($sibling->isa('PPI::Token::Quote') && $sibling->content =~ /\$ARGV|\$input|\$filename|\$file/)
        ) {
            return $self->violation($DESC, $EXPL, $elem);
        }
        $sibling = $sibling->snext_sibling;
    }

    return;
}

1;
