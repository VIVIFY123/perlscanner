package Perl::Critic::Policy::MySecurity::Stored_XSS;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;
use PPI;

Readonly::Scalar my $DESC     => 'Possible Stored Cross-Site Scripting (Stored XSS) - CWE-79';
Readonly::Scalar my $EXPL     => 'User input is stored and later printed without sanitization, allowing persistent XSS.';
Readonly::Scalar my $SEVERITY => 5;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_high_risk',
            behavior       => 'string',
        }
    );
}

sub default_severity { return 5 } 
sub default_themes   { return qw(perl_high_risk) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Statement');
    return unless $elem->content =~ /\bprint\b/;

    # Phase 1: Build taint map
    my %tainted;
    my $s = $elem;
    while ($s = $s->sprevious_sibling) {
        next unless $s->isa('PPI::Statement');
        my $line = $s->content;

        if ($line =~ /my\s+(\$\w+)\s*=\s*<STDIN>/i) {
            $tainted{$1} = 1;
        }
        elsif ($line =~ /my\s+(\$\w+)\s*=\s*(\$\w+)/) {
            $tainted{$1} = 1 if $tainted{$2};
        }
    }

    # Phase 2: Check print strings for interpolated tainted vars
    my $quote_nodes = $elem->find('PPI::Token::Quote::Double') || [];
    foreach my $quote (@$quote_nodes) {
        my $qcontent = $quote->content;
        while ($qcontent =~ /(\$\w+)/g) {
            my $varname = $1;
            if ($tainted{$varname}) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }
    }

    return;
}

1;

