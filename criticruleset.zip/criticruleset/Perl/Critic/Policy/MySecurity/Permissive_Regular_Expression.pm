package Perl::Critic::Policy::MySecurity::Permissive_Regular_Expression;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Permissive Regular Expression (CWE-625)';
Readonly::Scalar my $EXPL     => 'Avoid overly permissive regex patterns such as .* without anchors or length limits.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Token::Regexp' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $regex = $elem->content;

    # Catch overly broad regex like .* or .*
    if ($regex =~ m{^\s*/\.\*[^+?]} && $regex !~ m{\^|\$|\{|\d}) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
