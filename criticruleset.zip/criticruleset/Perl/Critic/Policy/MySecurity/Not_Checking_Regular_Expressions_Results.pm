package Perl::Critic::Policy::MySecurity::Not_Checking_Regular_Expressions_Results;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Not Checking Regular Expression Results (CWE-252)';
Readonly::Scalar my $EXPL     => 'Check the return value of regular expressions. Do not ignore the result.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;

    my $code = $elem->content;

    # Only scan lines with =~ or !~ for regex
    return unless $code =~ /\s*(?:=~|!~)\s*m?[qr]?\/.*\/[a-z]*\s*;$/;

    # Now check if used within if, unless, while, etc. – then skip
    return if $code =~ /^\s*(?:if|unless|while|elsif)\b/;

    # Now check if the result is actually stored or handled
    return unless $code !~ /=\s*(?:[01]|\$[a-zA-Z_]\w*)/;

    return $self->violation($DESC, $EXPL, $elem);
}

1;
