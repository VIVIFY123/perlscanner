package Perl::Critic::Policy::MySecurity::XXE;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible XXE (CWE-611)';
Readonly::Scalar my $EXPL => 'Improper restriction of XML external entity resolution. Avoid using XML::Simple, XML::LibXML, or XML::Parser with untrusted input.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 } # Medium
sub default_themes   { return qw(security perl_medium_threat xxe) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $word = $elem->content;
    return unless $word =~ /^(XMLin|parse_string|parse)$/;

    return $self->violation($DESC, $EXPL, $elem);
}

1;
