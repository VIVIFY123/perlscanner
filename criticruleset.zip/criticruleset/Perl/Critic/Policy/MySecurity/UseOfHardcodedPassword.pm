package Perl::Critic::Policy::MySecurity::UseOfHardcodedPassword;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-259: Use of Hardcoded Password
Readonly::Scalar my $DESC => 'Possible Use of Hardcoded Password (CWE-259)';
Readonly::Scalar my $EXPL => 'Avoid hardcoding credentials like passwords, tokens, or API keys in code. Use secure vaults or environment variables.';

sub applies_to {
    return 'PPI::Statement::Variable';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat hardcoded_password) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Statement::Variable');
    my $code = $elem->content;

    if (
        $code =~ /\$(password|passwd|token|secret|key|api_key)\b/i &&
        $code =~ /(['"]).+?\1/
    ) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
