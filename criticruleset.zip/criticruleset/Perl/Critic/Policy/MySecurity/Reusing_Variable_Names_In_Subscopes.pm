package Perl::Critic::Policy::MySecurity::Reusing_Variable_Names_In_Subscopes;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Reusing Variable Names in Subscopes (CWE-398)';
Readonly::Scalar my $EXPL     => 'Avoid reusing variable names in nested or inner scopes — it reduces readability and increases error risk.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_best_coding_practice) }
sub applies_to           { return 'PPI::Statement::Variable' }

sub violates {
    my ($self, $elem, $doc) = @_;

    my $var_token = $elem->find_first('PPI::Token::Symbol');
    return unless $var_token;
    my $name = $var_token->content;

    # Traverse parent scopes looking for same-named variable declarations
    my $scope = $elem->statement->parent;
    while ($scope) {
        my $vars_ref = $scope->find('PPI::Statement::Variable');
        if ($vars_ref) {
            foreach my $var (@$vars_ref) {
                next if $var == $elem;  # Skip self
                my $token = $var->find_first('PPI::Token::Symbol');
                next unless $token;
                if ($token->content eq $name) {
                    return $self->violation($DESC, $EXPL, $elem);
                }
            }
        }
        $scope = $scope->parent;
    }

    return;
}

1;
