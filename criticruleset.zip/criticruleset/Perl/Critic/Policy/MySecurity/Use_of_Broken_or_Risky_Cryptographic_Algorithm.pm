package Perl::Critic::Policy::MySecurity::Use_of_Broken_or_Risky_Cryptographic_Algorithm;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Use of Broken or Risky Cryptographic Algorithm (CWE-327)';
Readonly::Scalar my $EXPL     => 'Avoid using weak hashing functions like MD5 or SHA1 for cryptographic purposes.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $code = $elem->content;

    if ($code =~ /\b(?:md5|md5_hex|md5_base64|sha1|sha1_hex|sha1_base64)\b/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
