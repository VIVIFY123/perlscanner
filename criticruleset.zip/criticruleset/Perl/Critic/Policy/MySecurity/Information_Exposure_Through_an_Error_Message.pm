package Perl::Critic::Policy::MySecurity::Information_Exposure_Through_an_Error_Message;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Information Exposure Through an Error Message (CWE-209)';
Readonly::Scalar my $EXPL => 'Avoid exposing user-controlled input in error messages like die, warn, confess, or croak.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 1 }
sub default_themes   { return qw(security perl_low_visibility info_leak) }

sub violates {
    my ($self, $elem, undef) = @_;

    return unless $elem->isa('PPI::Token::Word');
    my $content = $elem->content;

    return unless $content =~ /^(die|warn|confess|croak)$/;

    my $next = $elem->snext_sibling or return;

    # Look for user input exposure via double-quoted strings with variables
    if ($next->isa('PPI::Structure::List')) {
        my $strings = $next->find('PPI::Token::Quote::Double');
        if ($strings) {
            foreach my $str (@$strings) {
                return $self->violation($DESC, $EXPL, $elem) if $str->content =~ /\$[a-zA-Z_]\w*/;
            }
        }
    } elsif ($next->isa('PPI::Token::Quote::Double')) {
        return $self->violation($DESC, $EXPL, $elem) if $next->content =~ /\$[a-zA-Z_]\w*/;
    }

    return;
}

1;
