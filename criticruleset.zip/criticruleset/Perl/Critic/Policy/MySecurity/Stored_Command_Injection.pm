package Perl::Critic::Policy::MySecurity::Stored_Command_Injection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Stored Command Injection (CWE-77)';
Readonly::Scalar my $EXPL => 'User input is stored and later passed to system commands without validation. This can lead to OS command injection.';
Readonly::Scalar my $SEVERITY => 3;

my @command_funcs = qw(system exec open qx backticks);
my @sources = (
    '\$ENV\s*\{[^\}]+\}',
    'param\s*\(',
    'cgi->param\s*\(',
    'CGI->new',
    'query->param\s*\(',
    '\$q\s*->\s*param',
    '\$input\s*->\s*param',
);

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Stored Command Injection detection.',
            default_string => 'perl_medium_threat',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_medium_threat) }
sub applies_to           { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, $doc) = @_;
    my $code = $elem->content;

    foreach my $src (@sources) {
        if ($code =~ /$src/ && $code =~ /=/) {
            return;  # assignment only — storing, not triggering
        }
    }

    foreach my $cmd (@command_funcs) {
        if ($code =~ /\b$cmd\b/ && $code =~ /\$\w+/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
