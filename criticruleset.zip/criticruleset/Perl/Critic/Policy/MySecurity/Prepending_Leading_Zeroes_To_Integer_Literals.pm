package Perl::Critic::Policy::MySecurity::Prepending_Leading_Zeroes_To_Integer_Literals;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Prepending Leading Zeroes to Integer Literals (CWE-665)';
Readonly::Scalar my $EXPL => 'Avoid prepending leading zeroes to integers unless you mean to define an octal number.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_best_coding_practice) }
sub applies_to           { return 'PPI::Token::Number' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $content = $elem->content;

    return if $content !~ /^0\d+/;     # Only trigger on integers starting with leading 0

    return $self->violation($DESC, $EXPL, $elem);
}

1;
