package Perl::Critic::Policy::MySecurity::Log_Forging;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;
use Scalar::Util qw(blessed);

Readonly::Scalar my $DESC => 'Log Forging (CWE-117)';
Readonly::Scalar my $EXPL => 'Avoid logging unsanitized user input which may forge log entries.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_low_visibility) }
sub applies_to           { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;

    my $code = $elem->content;
    return if $code !~ /\b(?:warn|print|log|logger|debug)\b.*\$/i;

    if ($code =~ /\$[a-zA-Z_]\w*/) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
