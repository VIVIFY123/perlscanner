package Perl::Critic::Policy::MySecurity::CommandInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Command Injection (CWE-77)';
Readonly::Scalar my $EXPL => 'User input is passed to system, exec, or backticks without sanitization. Use IPC::Run or validate input strictly.';
Readonly::Scalar my $SEVERITY => 5;

my @dangerous_calls = (
    'system',
    'exec',
    'qx',
    '`',
    'open\s*\(.*?,\s*"\|',    # open with pipe
);

my @sources = (
    '\$ENV\s*\{[^\}]+\}',
    'param\s*\(',
    'cgi->param\s*\(',
    '\$q\s*->\s*param',
    '\$input\s*->\s*param',
    '\$stored_cmd',
    '\$user_input',
);

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Command Injection detection.',
            default_string => 'perl_high_risk',
            behavior       => 'string',
        }
    );
}

sub default_severity { return 5 } 
sub default_themes       { return qw(perl_high_risk) }
sub applies_to           { return 'PPI::Token::Word' }

sub violates {
    my ($self, $elem, $doc) = @_;
    my $code = $elem->statement->content;

    foreach my $call (@dangerous_calls) {
        foreach my $src (@sources) {
            if ($code =~ /\b$call\b/ && $code =~ /$src/) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }
    }

    # Also catch backtick usage not covered by qx
    if ($code =~ /`[^`]*\$(\w+)[^`]*`/) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;

