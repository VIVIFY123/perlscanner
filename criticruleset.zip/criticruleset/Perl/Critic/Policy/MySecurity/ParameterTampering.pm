package Perl::Critic::Policy::MySecurity::ParameterTampering;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Parameter Tampering (CWE-472)';
Readonly::Scalar my $EXPL => 'User-controlled input is used in logical conditions to influence program flow. Ensure input is validated.';

sub applies_to       { return 'PPI::Token::Word' }
sub default_severity { return 3 }
sub default_themes   { return qw(security perl_medium_threat parameter_tampering) }

# Attack vector patterns (regex-safe)
my @taint_patterns = (
    qr/\$ARGV(?:\[\d+\])?/,              # $ARGV[0]
    qr/\$ENV(?:\{.*?\})?/,               # $ENV{'X'}
    qr/\$param(?:\{.*?\})?/,             # $param{'X'}
    qr/\$input/,                         # $input
    qr/\$amount/,                        # $amount
    qr/\$data/,                          # $data
    qr/\$price/,                         # $price
    qr/\$req->param\([^)]+\)/,           # $req->param("admin")
    qr/\$q->param\([^)]+\)/,             # $q->param("foo")
    qr/\$json(?:->\{.*?\})?/,            # $json->{'isAdmin'}
);

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content eq 'if' || $elem->content eq 'unless';

    my $cond = $elem->snext_sibling;
    return unless $cond && $cond->isa('PPI::Structure::Condition');

    my $condition_code = $cond->content;

    foreach my $regex (@taint_patterns) {
        if ($condition_code =~ /$regex/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;

