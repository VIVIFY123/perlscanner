package Perl::Critic::Policy::MySecurity::Overloading_Reserved_Keywords_or_Subroutines;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Overloading Reserved Keywords or Subroutines (CWE-398)';
Readonly::Scalar my $EXPL => 'Avoid redefining Perl reserved functions like open, print, system, etc.';
Readonly::Scalar my $SEVERITY => 1;

my @reserved = qw(open print system exec die exit select fork sleep return require use);

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_low_visibility) }
sub applies_to           { return 'PPI::Statement::Sub' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $name = $elem->name || return;

    foreach my $reserved (@reserved) {
        if (lc($name) eq $reserved) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
