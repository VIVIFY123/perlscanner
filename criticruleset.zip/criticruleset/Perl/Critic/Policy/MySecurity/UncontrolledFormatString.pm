package Perl::Critic::Policy::MySecurity::UncontrolledFormatString;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-134: Uncontrolled Format String
Readonly::Scalar my $DESC => 'Possible Uncontrolled Format String (CWE-134)';
Readonly::Scalar my $EXPL => 'Avoid passing user-controlled input directly into format functions like printf, sprintf, warn, or log. Always use explicit format specifiers.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat uncontrolled_format_string) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(printf|sprintf|warn|log)$/;

    my $sibling = $elem->snext_sibling;
    return unless $sibling && $sibling->isa('PPI::Structure::List');

    my @children = $sibling->schildren;
    return unless @children;

    # Grab the first argument passed to the function
    my $first_arg = $children[0]->content;

    # Detect common user-controlled input patterns
    if ($first_arg =~ /\$?(ARGV|input|data|params?\[|cgi|query|get_param|get|post)/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
