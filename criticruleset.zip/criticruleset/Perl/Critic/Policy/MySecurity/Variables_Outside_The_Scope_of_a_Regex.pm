package Perl::Critic::Policy::MySecurity::Variables_Outside_The_Scope_of_a_Regex;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Variables Outside the Scope of a Regex (CWE-824)';
Readonly::Scalar my $EXPL => 'Avoid using regex metacharacters referencing variables (e.g., $1, $2) outside valid regex context.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_low_visibility) }
sub applies_to           { return 'PPI::Token::Symbol' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $symbol = $elem->content;

    return if $symbol !~ /^\$\d+$/;  # Only match $1, $2, etc.

    # Only flag if not inside a regex structure (simplified heuristic)
    my $parent = $elem->parent;
    return if defined($parent) && $parent->content =~ /m?\s*\/.*?\$\d+.*?\//;

    return $self->violation($DESC, $EXPL, $elem);
}

1;
