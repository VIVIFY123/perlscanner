package Perl::Critic::Policy::MySecurity::Signifying_Inheritence_At_Runtime;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC     => 'Signifying Inheritance at Runtime (CWE-398)';
Readonly::Scalar my $EXPL     => 'Avoid assigning inheritance dynamically at runtime using @ISA.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_low_visibility',
            behavior       => 'string',
        }
    );
}

sub default_severity { return $SEVERITY }
sub default_themes   { return qw(perl_low_visibility) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $code = $elem->content;

    # Detect assignment to @ISA (used to set inheritance at runtime)
    if ($code =~ /\@ISA\s*=\s*\(?\s*['"]?\w+['"]?\s*\)?/) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
