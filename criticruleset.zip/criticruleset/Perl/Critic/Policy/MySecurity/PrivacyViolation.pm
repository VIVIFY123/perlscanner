package Perl::Critic::Policy::MySecurity::PrivacyViolation;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-359: Privacy Violation
Readonly::Scalar my $DESC => 'Possible Privacy Violation (CWE-359)';
Readonly::Scalar my $EXPL => 'Sensitive information (e.g., password, email, SSN, token) is being printed or logged. Mask or avoid exposing such data.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat privacy_violation) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(print|warn|log|write|info|debug)$/;

    my $sibling = $elem->snext_sibling;
    while ($sibling) {
        # Case 1: print("something $password");
        if ($sibling->isa('PPI::Structure::List')) {
            my $list_content = $sibling->content;
            if ($list_content =~ /\$?(password|passwd|email|ssn|social|token|auth|secret)/i) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }

        # Case 2: print "User password is $password";
        if (
            $sibling->isa('PPI::Token::Quote::Double') ||
            $sibling->isa('PPI::Token::Quote::Single')
        ) {
            if ($sibling->content =~ /\$?(password|passwd|email|ssn|social|token|auth|secret)/i) {
                return $self->violation($DESC, $EXPL, $elem);
            }
        }

        $sibling = $sibling->snext_sibling;
    }

    return;
}

1;
