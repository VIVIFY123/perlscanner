package Perl::Critic::Policy::MySecurity::Hardcoded_Absolute_Path;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Hardcoded Absolute Path (CWE-426)';
Readonly::Scalar my $EXPL => 'Avoid hardcoded absolute file paths like /tmp/file.txt or C:\\path\\file.txt.';
Readonly::Scalar my $SEVERITY => 1;

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Dummy theme param to allow .perlcriticrc support.',
            default_string => 'perl_best_coding_practice',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_best_coding_practice) }
sub applies_to           { return 'PPI::Token::Quote' }

sub violates {
    my ($self, $elem, undef) = @_;
    my $content = $elem->content;

    return if $content !~ m{(?:(?:['"])\/(?:[^'"]+)|(?:[A-Za-z]:\\[^'"]+))};  # UNIX or Windows abs path
    return $self->violation($DESC, $EXPL, $elem);
}

1;
