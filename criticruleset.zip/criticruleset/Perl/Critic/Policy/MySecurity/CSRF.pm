package Perl::Critic::Policy::MySecurity::CSRF;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible CSRF (CWE-352)';
Readonly::Scalar my $EXPL => 'State-changing request detected (e.g., POST/DELETE) without CSRF token validation.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat csrf) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    my $content = $elem->content;

    # Look for HTTP method inspection or param use
    return unless $content =~ /^(param|request_method|get|post|delete|put)$/i;

    my $doc_text = $doc->serialize;

    # If POST/DELETE/PUT found but no CSRF validation, trigger violation
    if ($doc_text =~ /\b(POST|DELETE|PUT)\b/i && $doc_text !~ /\b(csrf_token|check_csrf|verify_token)\b/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
