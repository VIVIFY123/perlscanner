package Perl::Critic::Policy::MySecurity::ResourceInjection;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Resource Injection (CWE-99)';
Readonly::Scalar my $EXPL => 'Avoid using user-controlled input in file/resource handling functions like open, sysopen, require, or do.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk resource_injection) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');

    my $function = $elem->content;
    return unless $function =~ /^(open|sysopen|require|do)$/;

    my $sibling = $elem->snext_sibling;
    return unless $sibling && $sibling->isa('PPI::Structure::List');

    my $found = $sibling->find_any(sub {
        my ($top, $child) = @_;
        return $child->isa('PPI::Token::Symbol') && $child->content =~ /^\$/;
    });

    if ($found) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
