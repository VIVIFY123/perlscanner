package Perl::Critic::Policy::MySecurity::ReflectedXSS;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;
use PPI;

Readonly::Scalar my $DESC     => 'Possible Reflected XSS (CWE-79)';
Readonly::Scalar my $EXPL     => 'User input echoed directly into HTML output via print or string interpolation.';
Readonly::Scalar my $SEVERITY => 5;

sub default_severity { return 5 } 
sub default_themes   { return qw(perl_high_risk) }
sub applies_to       { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Statement');
    return unless $elem->content =~ /\bprint\b/;

    my $found = 0;

    # Look for interpolated vars inside double-quoted print
    my $quote_nodes = $elem->find('PPI::Token::Quote::Double');
    if ($quote_nodes) {
        foreach my $q (@$quote_nodes) {
            if ($q->content =~ /\$\w+/) {
                $found = 1;
                last;
            }
        }
    }

    # Also check plain symbol arguments to print (e.g., print $user_input)
    my $symbol_nodes = $elem->find('PPI::Token::Symbol');
    if ($symbol_nodes) {
        foreach my $sym (@$symbol_nodes) {
            if ($sym->content =~ /^\$\w+$/) {
                $found = 1;
                last;
            }
        }
    }

    if ($found) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;

