# dump_ppi.pl
use PPI;
use PPI::Dumper;

my $doc = PPI::Document->new($ARGV[0]);
my $dumper = PPI::Dumper->new($doc);
$dumper->print;

