#!/bin/bash

# ==============================================================================
# run_all_scans_html.sh — same scan logic, HTML tables with summary at top
# ==============================================================================

# ----- Prompts -----
echo "Enter the path to the directory you want to scan (e.g., Testing/):"
read -r TARGET_DIR
echo "Enter the folder where the HTML should be saved (e.g., Reports/):"
read -r OUTPUT_DIR
echo "Enter the name of the HTML file (without .html):"
read -r HTML_BASE

# ----- Validation -----
if [ -z "$TARGET_DIR" ] || [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Invalid scan directory."
  exit 1
fi
if [ -z "$OUTPUT_DIR" ]; then
  echo "Error: No output directory provided."
  exit 1
fi
if [ -z "$HTML_BASE" ]; then
  echo "Error: No HTML file name provided."
  exit 1
fi

mkdir -p "$OUTPUT_DIR"
OUTPUT_PATH="$OUTPUT_DIR/$HTML_BASE.html"

# ----- Accumulators -----
declare -A FILE_TOTALS
declare -A FILE_ISSUES

GRAND_HIGH=0
GRAND_MED=0
GRAND_LOW=0
GRAND_INFO=0

# ----- helper to run a section -----
run_section () {
  local file="$1" theme="$2" cat_id="$3" count_var="$4"

  local out
  out=$(PERL5LIB=$PWD perlcritic --theme "$theme" "$file" 2>&1)

  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    [[ "$line" == *"source OK"* ]] && continue

    # Parse: "[ID] Issue text (CWE-xx) at line xx, column xx. description.  (Severity: n)"
    local issue_text location rest
    issue_text=$(echo "$line" | sed -E 's/^\[.*\] (.*) at line .*/\1/')
    location=$(echo "$line" | sed -nE 's/^.* at line ([0-9]+), column ([0-9]+)\..*/Line \1, Col \2/p')
    rest=$(echo "$line" | sed -E 's/^.*\.  (.*)  \(Severity: ([0-9]+)\)$/\1|Severity: \2/')

    FILE_ISSUES["$file"]+="$cat_id|||$issue_text|||$location|||$rest"$'\n'
  done <<< "$out"

  local count
  count=$(printf "%s\n" "$out" | sed '/^[[:space:]]*$/d' | grep -v 'source OK' | wc -l)
  eval "$count_var=$count"
}

# ----- collect files -----
mapfile -d '' FILES < <(find "$TARGET_DIR" -type f -name "*.pl" -print0)
if [ "${#FILES[@]}" -eq 0 ]; then
  echo "No .pl files found in '$TARGET_DIR'."
  exit 0
fi

# ----- scan -----
for file in "${FILES[@]}"; do
  HIGH_COUNT=0
  MED_COUNT=0
  LOW_COUNT=0
  INFO_COUNT=0

  run_section "$file" "perl_high_risk"           "HIGH-001" "HIGH_COUNT"
  run_section "$file" "perl_medium_threat"       "MED-001"  "MED_COUNT"
  run_section "$file" "perl_low_visibility"      "LOW-001"  "LOW_COUNT"
  run_section "$file" "perl_best_coding_practice" "INFO-001" "INFO_COUNT"

  GRAND_HIGH=$((GRAND_HIGH + HIGH_COUNT))
  GRAND_MED=$((GRAND_MED + MED_COUNT))
  GRAND_LOW=$((GRAND_LOW + LOW_COUNT))
  GRAND_INFO=$((GRAND_INFO + INFO_COUNT))

  TOTAL_FOR_FILE=$((HIGH_COUNT + MED_COUNT + LOW_COUNT + INFO_COUNT))
  FILE_TOTALS["$file"]=$TOTAL_FOR_FILE
done

# ----- HTML Header -----
cat > "$OUTPUT_PATH" <<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Perl SAST Ultra — Scan Report</title>
<style>
body { font-family: Arial, sans-serif; background:#f5f6fa; color:#333; margin:20px; }
h1 { color:#2c3e50; }
h2 { color:#34495e; }
table { border-collapse: collapse; width:100%; margin-bottom:30px; }
th, td { border:1px solid #ccc; padding:8px; text-align:left; vertical-align:top; }
th { background:#34495e; color:#fff; }
tr:nth-child(even) { background:#ecf0f1; }
.id-high { color:#c0392b; font-weight:bold; }
.id-med { color:#d35400; font-weight:bold; }
.id-low { color:#2980b9; font-weight:bold; }
.id-info { color:#27ae60; font-weight:bold; }
</style>
</head>
<body>
<h1>Perl SAST Ultra — Scan Report</h1>
<p><strong>Generated:</strong> $(date '+%Y-%m-%d %H:%M:%S %Z')</p>
EOF

# ----- Summary Table -----
cat >> "$OUTPUT_PATH" <<EOF
<h2>Summary (All Files)</h2>
<table>
<tr><th>Severity</th><th>Count</th></tr>
<tr><td class="id-high">[HIGH-001] High</td><td>$GRAND_HIGH</td></tr>
<tr><td class="id-med">[MED-001] Medium</td><td>$GRAND_MED</td></tr>
<tr><td class="id-low">[LOW-001] Low</td><td>$GRAND_LOW</td></tr>
<tr><td class="id-info">[INFO-001] Info</td><td>$GRAND_INFO</td></tr>
</table>
EOF

# ----- Top 5 Table -----
RANKED=$(for f in "${!FILE_TOTALS[@]}"; do
  printf "%s\t%s\n" "${FILE_TOTALS[$f]}" "$f"
done | sort -nr -k1,1 | head -5)

cat >> "$OUTPUT_PATH" <<EOF
<h2>Top 5 Most Vulnerable Files</h2>
<table>
<tr><th>Rank</th><th>File</th><th>Total Issues</th></tr>
EOF
i=1
while IFS=$'\t' read -r count path; do
  [[ -z "$count" || -z "$path" ]] && continue
  echo "<tr><td>$i</td><td>$path</td><td>$count</td></tr>" >> "$OUTPUT_PATH"
  i=$((i+1))
done <<< "$RANKED"
echo "</table>" >> "$OUTPUT_PATH"

# ----- Detailed Tables -----
cat >> "$OUTPUT_PATH" <<EOF
<h2>Detailed Results</h2>
EOF
for file in "${FILES[@]}"; do
  echo "<h3>$file</h3>" >> "$OUTPUT_PATH"
  echo "<table>" >> "$OUTPUT_PATH"
  echo "<tr><th>ID</th><th>Issue</th><th>Location</th><th>Description & Severity</th></tr>" >> "$OUTPUT_PATH"

  while IFS=$'|' read -r id issue location desc; do
    [[ -z "$id" ]] && continue
    # severity at end of desc
    desc_clean=$(echo "$desc" | tr -d '\r')
    id_class=""
    case "$id" in
      HIGH-001) id_class="id-high" ;;
      MED-001) id_class="id-med" ;;
      LOW-001) id_class="id-low" ;;
      INFO-001) id_class="id-info" ;;
    esac
    echo "<tr><td class=\"$id_class\">$id</td><td>$issue</td><td>$location</td><td>$desc_clean</td></tr>" >> "$OUTPUT_PATH"
  done <<< "$(echo "${FILE_ISSUES[$file]}" | sed 's/|||/|/g')"

  echo "</table>" >> "$OUTPUT_PATH"
done

# ----- HTML Footer -----
cat >> "$OUTPUT_PATH" <<EOF
</body>
</html>
EOF

echo "HTML report written to: $OUTPUT_PATH"

