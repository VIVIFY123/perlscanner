# CWE-134: Uncontrolled Format String

my $user_input = $ARGV[0];

# Direct usage in format functions
printf($user_input);
sprintf($user_input);
warn($user_input);
log($user_input);

# Safe usage (for contrast)
printf("User entered: %s\n", $user_input);
