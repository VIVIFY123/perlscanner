# ✅ Should trigger Use_of_Two_Argument_Form_of_Open
open FILE, "data.txt";

# ✅ Classic insecure pattern
open FILE, $user_input;

# ✅ Pipe attack
open FH, "|ls -l";

# ✅ 2-arg open with append mode
open LOG, ">>log.txt";

# ✅ 2-arg open with output
open OUT, ">output.txt";

# ✅ Secure 3-arg open (should NOT trigger)
open(my $fh, '<', "safe.txt");  # ✅ Secure
