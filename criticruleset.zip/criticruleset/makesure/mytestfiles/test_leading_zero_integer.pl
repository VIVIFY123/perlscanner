my $value1 = 0123;   # ❌ Looks decimal, but actually octal (83)
my $value2 = 077;    # ❌ Octal 77 (63 decimal)
my $value3 = 0x1F;   # ✅ Hexadecimal, allowed
my $value4 = 123;    # ✅ Decimal, no leading zero
