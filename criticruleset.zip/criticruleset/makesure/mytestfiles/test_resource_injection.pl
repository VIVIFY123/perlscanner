my $file = $ARGV[0];

open(my $fh, ">", $file);         # Dangerous
sysopen(my $fh2, $file, 1);       # Dangerous
require $file;                    # Dangerous
do $file;                         # Dangerous
