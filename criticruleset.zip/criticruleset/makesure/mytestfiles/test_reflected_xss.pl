use CGI;
my $q = CGI->new;

# ❌ Should trigger
print $ENV{'QUERY_STRING'};
print param("q");
print $q->param("msg");
warn $q->param("error");
die $q->param("error");

# ✅ Should NOT trigger
use HTML::Entities;
my $safe = encode_entities($q->param("clean"));
print $safe;
