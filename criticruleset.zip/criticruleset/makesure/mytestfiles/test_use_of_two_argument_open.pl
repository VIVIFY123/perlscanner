my $input = $ARGV[0];

# This is unsafe - 2-arg form
open FILE, "$input";

# Another unsafe form with pipe
open FILE, "cat $input";

# Safe - 3-arg form (should NOT be flagged)
open(my $fh, '<', $input);
