my $user = "admin";
my $pass = "supersecret";

# Insecure transport of credentials
my $url1 = "http://example.com/login?username=$user&password=$pass";
print $url1;

# Also insecure: tokens
my $token = "abc123";
my $url2 = "http://api.example.com/data?token=$token";
warn $url2;

# Secure version (should NOT trigger)
my $safe_url = "https://secure.example.com/login?username=admin&password=hidden";
print $safe_url;
