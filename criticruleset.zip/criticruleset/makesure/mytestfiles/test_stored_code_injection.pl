my $code = $ARGV[0];
eval $code;

my $input = $ARGV[1];
do $input;

my $payload = $ENV{'PAYLOAD'};
require $payload;

my $safe = 'print "hello"';
eval $safe;
