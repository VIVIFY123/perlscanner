my $file = $ARGV[0];

open my $fh, "<", $file or die "Cannot open file: $!";
unlink $file if -e $file;

my $folder = $ARGV[1];
mkdir $folder unless -d $folder;
