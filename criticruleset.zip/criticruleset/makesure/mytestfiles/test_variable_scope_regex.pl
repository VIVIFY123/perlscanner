my $input = "abc123";
$input =~ /(\d+)/;
print $1;  # ❌ Used outside proper regex context

if ($input =~ /(\w+)/) {
    print $1;  # ✅ Acceptable use within scope
}

my $value = $2;  # ❌ Used outside any match context
