my $name = $ARGV[0];

# Simple direct echo
print $name;

# Interpolated string
print "<div>$name</div>";

# Concatenated string
print "Hello " . $name;

# Edge case with HTML context
print "<script>let data = '$name';</script>";

