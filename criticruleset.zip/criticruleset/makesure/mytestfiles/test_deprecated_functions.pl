use CGI;
use Shell;

if (defined(@array)) {
    print "This is deprecated.";
}

reset $x;
