my $input = <STDIN>;
my $dsn = "dbi:mysql:database=$input";
my $dbh = DBI->connect($dsn, $user, $pass);

DBI->connect("dbi:mysql:host=$host;dbname=$dbname", $user, $pass);

