my $password = "hunter2";
our $token = 'abc123securetoken';
$api_key = "sk-12345";
my $username = "admin";   # Should NOT trigger
my $key = $ENV{'API_SECRET'};  # Should NOT trigger
