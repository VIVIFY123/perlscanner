my $method = $ENV{'REQUEST_METHOD'};

if ($method eq 'POST') {
    my $amount = param('amount');
    do_something_dangerous($amount);  # No CSRF check here
}
