# test_compromised_cdn.pl

print '<script src="http://cdn.unknownsource.com/jquery.js"></script>';
print '<script src="https://raw.githubusercontent.com/someproject/main.js"></script>';
print '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>';
