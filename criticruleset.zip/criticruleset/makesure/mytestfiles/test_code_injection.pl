eval($user_input);
eval("print $code;");
require $input;
do $input;

