# CWE-918 SSRF test cases

use LWP::UserAgent;
my $ua = LWP::UserAgent->new;

# Case 1: get request with tainted user input
my $url = $ARGV[0];
my $response1 = $ua->get($url);

# Case 2: another SSRF variant using POST
my $endpoint = $ENV{'TARGET_URL'};
my $response2 = $ua->post($endpoint);

# Case 3: direct socket call
use IO::Socket::INET;
my $host = $ARGV[1];
my $sock = IO::Socket::INET->new(PeerAddr => $host, PeerPort => '80', Proto => 'tcp');

# Safe example (should NOT trigger)
my $safe_response = $ua->get("https://example.com/static/info.html");
