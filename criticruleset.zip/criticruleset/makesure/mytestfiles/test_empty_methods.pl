# ❌ Violation: Empty subroutine
sub do_nothing { }

# ✅ Acceptable: Method with content
sub do_something {
    print "Working!\n";
}

# ✅ Acceptable: Placeholder with comment
sub will_implement {
    # TODO: implement this
}
