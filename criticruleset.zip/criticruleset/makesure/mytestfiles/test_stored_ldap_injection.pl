use Net::LDAP;

my $ldap = Net::LDAP->new('ldap.example.com') or die "$@";

my $user_input = $ARGV[0];
my $base = "ou=users,dc=example,dc=com";

# 👇 Stored LDAP Injection patterns
my $filter1 = "(uid=$user_input)";
$ldap->search(base => $base, filter => $filter1);

my $filter2 = "(&(objectClass=person)(cn=$user_input))";
$ldap->search(base => $base, filter => $filter2);
