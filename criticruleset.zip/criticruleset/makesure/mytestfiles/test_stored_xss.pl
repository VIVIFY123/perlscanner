# ✅ Vulnerable: user input stored then printed
my $user_input = $ENV{QUERY_STRING};
my $stored = $user_input;
print $stored;  # ❌ Stored XSS

# ✅ Also vulnerable (via CGI)
my $cgi = CGI->new;
my $comment = $cgi->param("comment");
print $comment;  # ❌ Stored XSS

# ✅ False positive prevention: safe encoding
use HTML::Entities;
print encode_entities($comment);  # ✅ Safe
