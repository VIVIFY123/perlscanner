my $user_input = param('name');

print $user_input;        # unescaped print
system($user_input);      # unsafe use in system
open(my $fh, ">", $user_input); # unsafe file handling
warn $user_input;         # unsafe log
