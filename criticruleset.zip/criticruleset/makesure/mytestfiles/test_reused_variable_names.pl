my $value = 42;

{
    my $value = 99;  # ❌ Same variable name reused in nested scope
    print $value;
}

print $value;  # ✅ Original outer variable
