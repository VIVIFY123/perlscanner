my $input = "abc123";

$input =~ /\d+/;  # ❌ Pattern matched but result ignored

if ($input =~ /\w+/) {  # ✅ Checked in control structure
    print "Letters found!\n";
}

my $result = ($input =~ /\D+/);  # ✅ Stored in a variable
