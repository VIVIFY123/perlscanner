# Test Case 1: Stored user input used in open()
my $filepath = $ARGV[0];
open(my $fh, "<", $filepath);

# Test Case 2: Stored file path in sysopen()
my $user_file = $ENV{'FILE_PATH'};
sysopen(my $fh2, $user_file, 0);

# Test Case 3: Stored variable used in unlink
my $input_file = $cgi->param("target");
unlink($input_file);
