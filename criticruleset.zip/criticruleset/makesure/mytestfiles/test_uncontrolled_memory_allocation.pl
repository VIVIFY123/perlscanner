my $size = $ARGV[0];
my @array;

# User-controlled memory allocation patterns
$x = "A" x $size;
my $buffer = "\0" x $ARGV[1];
my @user_array = (0) x $ARGV[2];
my $data = chr($ARGV[3]) x 100;
my $map = { map { $_ => 1 } (1..$ARGV[4]) };
my $joined = join('', 'a' x $ARGV[5]);
