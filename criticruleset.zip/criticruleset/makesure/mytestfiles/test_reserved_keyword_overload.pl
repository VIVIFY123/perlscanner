# ❌ Overloading built-in
sub open {
    print "Overloaded open\n";
}

sub my_custom_func {
    print "This is fine.\n";  # ✅ Allowed
}

# ❌ Overloading another core
sub print {
    return "Hijacked print";
}
