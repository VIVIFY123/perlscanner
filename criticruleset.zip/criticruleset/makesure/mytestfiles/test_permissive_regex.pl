my $input = "suspicious_input";

# ❌ Overly permissive regex
if ($input =~ /.*/) {
    print "Matched all\n";
}

# ✅ Safer regex with anchor
if ($input =~ /^\w+$/) {
    print "Matched word\n";
}

# ✅ Safe regex with quantifier control
if ($input =~ /.{1,10}/) {
    print "Matched limited\n";
}
