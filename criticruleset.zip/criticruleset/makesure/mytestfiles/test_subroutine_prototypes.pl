sub add($$) {  # ❌ Uses a prototype
    my ($a, $b) = @_;
    return $a + $b;
}

print add(2, 3);  # ✅ Still works but misleading
