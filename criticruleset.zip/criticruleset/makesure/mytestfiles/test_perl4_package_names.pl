package MyPackage'Legacy;

sub old_style {
    return 1;
}
