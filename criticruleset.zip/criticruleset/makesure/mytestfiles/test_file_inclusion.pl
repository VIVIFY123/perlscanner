require $input;
do $input;
open(FH, $user_file);
read(FH, $tainted_data, 100);
readline($filename);

