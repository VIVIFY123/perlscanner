my $user_input = param('username');

die "Error: $user_input not found";
warn("Warning: invalid value $user_input");
confess("Stack trace on $user_input");
