# ❌ Should trigger
sleep 30;
sleep($user_input);
sleep($ENV{SLEEP_TIME});

# ✅ Should not trigger
print "Sleeping is dangerous!\n";
