use strict;
use warnings;
use Digest::MD5 qw(md5 md5_hex);

my $data = "password";
my $digest1 = md5($data);       # ❌ Weak hash
my $digest2 = md5_hex($data);   # ❌ Weak hash

use Digest::SHA qw(sha256_hex);
my $secure = sha256_hex($data); # ✅ Secure
