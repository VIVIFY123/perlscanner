my $input = $ARGV[0];
my $user = $input;

$dbh->do("SELECT * FROM users WHERE name = '$user'");
$dbh->prepare("DELETE FROM accounts WHERE id = '$user'");
