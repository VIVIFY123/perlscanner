my $user_input = <STDIN>;
system($user_input);
