use CGI;
my $q = CGI->new;

# ✅ Should trigger: stored input reused in system call
my $user_input = $ENV{'USER_CMD'};
my $cmd1 = param("cmd");
my $cmd2 = $q->param("hack");

system($user_input);     # ❌
exec($cmd1);             # ❌
qx($cmd2);               # ❌
open(my $fh, "$user_input |"); # ❌

# ✅ Should NOT trigger
system("ls -l");
my $safe = "echo hello";
system($safe);
