use strict;
use warnings;

open(my $fh, '<', 'data.txt');  # ❌ Return value unchecked
close($fh);                     # ❌ Return value unchecked

if (!open(my $fh2, '<', 'data.txt')) {  # ✅ Checked
    die "Failed to open file: $!";
}

my $result = unlink 'temp.txt';  # ✅ Stored
