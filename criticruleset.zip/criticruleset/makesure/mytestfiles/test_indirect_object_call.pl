use strict;
use warnings;

# ❌ Indirect object call (bad)
my $bad_obj = new MyClass();

# ✅ Direct object call (good)
my $ok_obj = MyClass->new();
