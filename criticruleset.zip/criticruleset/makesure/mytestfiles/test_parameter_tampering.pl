my $role = $ARGV[0];

if ($role eq 'admin') {
    print "Access granted.\n";
}

if ($ARGV[1] eq 'delete') {
    print "Deleting record...\n";
}

unless ($ARGV[2] ne 'safe') {
    print "Unsafe action triggered.\n";
}
