my $user = $ARGV[0];

my $query = "SELECT * FROM users WHERE username = '$user'";
$dbh->prepare($query);

$dbh->prepare("SELECT * FROM users WHERE id = $user");

$dbh->do("DELETE FROM users WHERE id = " . $user);

my $sql = "INSERT INTO log VALUES ('$user')";
$dbh->do($sql);
