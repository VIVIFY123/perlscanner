use strict;
use warnings;

# ❌ Runtime inheritance assignment (bad)
our @ISA = ('BaseClass');

# ✅ Recommended way (good)
use parent 'BaseClass';
