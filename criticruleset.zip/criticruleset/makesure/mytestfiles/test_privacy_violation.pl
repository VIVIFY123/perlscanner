my $password = $ARGV[0];
my $email = $ARGV[1];
my $ssn = "123-45-6789";
my $token = "abc123securetoken";

print "User password is: $password\n";
warn "Emailed user at $email\n";
print "SSN = $ssn\n";
print "Auth token: $token\n";
