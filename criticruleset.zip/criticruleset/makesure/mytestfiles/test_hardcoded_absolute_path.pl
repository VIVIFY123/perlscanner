my $linux_path  = "/tmp/data.log";         # ❌ Hardcoded absolute path
my $windows_path = "C:\\logs\\event.log";  # ❌ Hardcoded absolute path

my $relative_path = "data/output.txt";     # ✅ Relative path (safe)
