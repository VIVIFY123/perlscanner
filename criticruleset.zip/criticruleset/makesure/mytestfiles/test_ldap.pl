my $username = <STDIN>;
my $filter = "(uid=$username)";
$ldap->search(filter => $filter);

$ldap->search(filter => "(&(uid=$username)(group=admins))");

Net::LDAP->new("ldap://$host");

