cat <<EOF > Testing/test_dos_by_sleep.pl
my \$delay = \$ARGV[0];
sleep(\$delay);
select(undef, undef, undef, \$delay);
alarm(\$delay);
EOF

