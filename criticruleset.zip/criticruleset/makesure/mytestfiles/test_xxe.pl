use XML::Simple;
use XML::LibXML;
use XML::Parser;

my $xml_data = $ARGV[0];

# Vector 1: XML::Simple parsing untrusted data
my $simple = XMLin($xml_data);

# Vector 2: XML::LibXML with unconfigured parser
my $parser = XML::LibXML->new();
my $doc = $parser->parse_string($xml_data);

# Vector 3: XML::Parser default behavior
my $xp = XML::Parser->new();
$xp->parse($xml_data);
