package Perl::Critic::Policy::MySecurity::Reflected_XSS;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Reflected Cross-Site Scripting (Reflected XSS) - CWE-79';
Readonly::Scalar my $EXPL => 'User input is directly reflected in output without sanitization. Use encode_entities or HTML::Escape.';
Readonly::Scalar my $SEVERITY => 5;

my @sources = (
    '\$ENV\s*\{[^\}]+\}',
    'param\s*\(',
    'cgi->param\s*\(',
    'CGI->new',
    'query->param\s*\(',
    '\$q\s*->\s*param',
    '\$input\s*->\s*param',
);

sub supported_parameters {
    return (
        {
            name           => 'theme',
            description    => 'Reflected XSS detection.',
            default_string => 'perl_high_risk',
            behavior       => 'string',
        }
    );
}

sub default_severity     { return $SEVERITY }
sub default_themes       { return qw(perl_high_risk) }
sub applies_to           { return 'PPI::Statement' }

sub violates {
    my ($self, $elem, $doc) = @_;
    my $code = $elem->content;

    return if $code =~ /encode_entities|escapeHTML/;

    foreach my $src (@sources) {
        if ($code =~ /$src/ && $code =~ /\bprint\b|\bwarn\b|\bdie\b/) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
