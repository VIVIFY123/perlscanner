package Perl::Critic::Policy::MySecurity::DeprecatedFunctions;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Perl::Critic::Utils qw(:severities);
use Readonly;



Readonly::Scalar my $DESC => 'Use of deprecated Perl function or module (CWE-477)';
Readonly::Scalar my $EXPL => 'Avoid using deprecated functions or modules. These may be removed in future versions or pose security risks.';

sub supported_parameters { return () }

sub default_severity     { return $SEVERITY_LOW }

sub applies_to           { return 'PPI::Token::Word' }

# Force theme support even on older Perl::Critic
sub initialize_if_enabled {
    my ($class, $config) = @_;
    return if not $config->policy_is_enabled($class);
    my $self = bless {}, $class;
    $self->{_themes} = ['perl_low_visibility'];  # 💥 FORCE THEME HERE
    return $self;
}

my @DEPRECATED_FUNCTIONS = qw(
    setlocale
    defined
    dump
    goto
    reset
    study
    CGI
    Shell
    Switch
);

sub violates {
    my ($self, $elem, $doc) = @_;

    my $content = $elem->content;

    foreach my $bad (@DEPRECATED_FUNCTIONS) {
        if (lc($content) eq lc($bad)) {

            # Special case: only warn on defined(@array), not defined($scalar)
            if ($bad eq 'defined') {
                my $sibling = $elem->snext_sibling;
                if ($sibling && $sibling->content eq '(') {
                    my $next = $sibling->snext_sibling;
                    if ($next && $next->content eq '@') {
                        return $self->violation($DESC, $EXPL, $elem);
                    }
                    return; # defined($var) is OK
                }
            }

            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
