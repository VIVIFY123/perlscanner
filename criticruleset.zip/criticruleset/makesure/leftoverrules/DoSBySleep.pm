package Perl::Critic::Policy::MySecurity::DoSBySleep;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-834: DoS via sleep/time-based delays
Readonly::Scalar my $DESC => 'Possible Denial of Service via time-based function (CWE-834)';
Readonly::Scalar my $EXPL => 'Avoid using sleep(), alarm(), or select() with variable or dynamic input. Can be abused for DoS attacks.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 } # Medium
sub default_themes   { return qw(security perl_medium_threat dos delay) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    my $func = $elem->content;

    return unless $func =~ /^(sleep|select|alarm|usleep)$/;

    my $structure = $elem->snext_sibling;
    return unless $structure && $structure->isa('PPI::Structure::List');

    my @tokens = $structure->tokens;

    foreach my $token (@tokens) {
        # Match user-controlled input or interpolated symbols
        if ($token->isa('PPI::Token::Symbol') || 
            ($token->isa('PPI::Token::Quote::Double') && $token->content =~ /\$\w+/) ||
            ($token->isa('PPI::Token::Operator') && $token->content eq '.') ||
            ($token->isa('PPI::Token::Magic'))) {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
