package Perl::Critic::Policy::MySecurity::StoredXSS;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

Readonly::Scalar my $DESC => 'Possible Stored XSS (CWE-79)';
Readonly::Scalar my $EXPL => 'User input stored in variables and later echoed into HTML. Sanitize before storing or printing.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 5 }
sub default_themes   { return qw(security perl_high_risk xss stored_xss) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content eq 'print';

    my $sibling = $elem->snext_sibling;
    return unless $sibling && $sibling->isa('PPI::Structure::List');

    my @tokens = $sibling->tokens;

    foreach my $token (@tokens) {
        # Basic symbol
        if ($token->isa('PPI::Token::Symbol') && $token->content =~ /^\$db_data$/) {
            return $self->violation($DESC, $EXPL, $elem);
        }

        # Double-quoted string containing $db_data
        if ($token->isa('PPI::Token::Quote::Double') && $token->content =~ /\$db_data\b/) {
            return $self->violation($DESC, $EXPL, $elem);
        }

        # Concatenated output like 'foo' . $db_data
        if ($token->isa('PPI::Token::Operator') && $token->content eq '.') {
            return $self->violation($DESC, $EXPL, $elem);
        }
    }

    return;
}

1;
