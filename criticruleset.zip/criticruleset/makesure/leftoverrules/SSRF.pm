package Perl::Critic::Policy::MySecurity::SSRF;

use strict;
use warnings;
use parent 'Perl::Critic::Policy';
use Readonly;

# CWE-918: Server-Side Request Forgery
Readonly::Scalar my $DESC => 'Possible SSRF (CWE-918)';
Readonly::Scalar my $EXPL => 'Avoid making requests to user-supplied URLs without validation. SSRF can lead to internal resource access.';

sub applies_to {
    return 'PPI::Token::Word';
}

sub default_severity { return 3 }  # Medium
sub default_themes   { return qw(security perl_medium_threat ssrf) }

sub violates {
    my ($self, $elem, $doc) = @_;

    return unless $elem->isa('PPI::Token::Word');
    return unless $elem->content =~ /^(get|post|ua|mirror|simple_request|request)$/i;

    my $parent = $elem->parent;
    return unless $parent;

    my $sibling = $elem->snext_sibling;
    return unless $sibling;

    my $code = $sibling->content || '';
    if ($code =~ /\$?(url|target|endpoint|uri|domain)/i) {
        return $self->violation($DESC, $EXPL, $elem);
    }

    return;
}

1;
