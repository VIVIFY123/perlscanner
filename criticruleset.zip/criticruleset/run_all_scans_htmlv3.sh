#!/bin/bash

# ==============================================================================
# run_all_scans_html.sh — HTML report with Summary + Top 5 + Detailed tables
# Now adds a 4th "Context" column showing 2 lines before/after and the
# exact offending line highlighted in yellow. Logic/IDs unchanged.
# ==============================================================================

# ----- Prompts -----
echo "Enter the path to the directory you want to scan (e.g., Testing/):"
read -r TARGET_DIR
echo "Enter the folder where the HTML should be saved (e.g., Reports/):"
read -r OUTPUT_DIR
echo "Enter the name of the HTML file (without .html):"
read -r HTML_BASE

# ----- Validation -----
if [ -z "$TARGET_DIR" ] || [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Invalid scan directory."
  exit 1
fi
if [ -z "$OUTPUT_DIR" ]; then
  echo "Error: No output directory provided."
  exit 1
fi
if [ -z "$HTML_BASE" ]; then
  echo "Error: No HTML file name provided."
  exit 1
fi

mkdir -p "$OUTPUT_DIR"
OUTPUT_PATH="$OUTPUT_DIR/$HTML_BASE.html"

# ----- Utilities -----
html_escape() {
  # escape &, <, >
  sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'
}

make_context_html() {
  # Args: file path, 1-based line number
  local file="$1"
  local line_no="$2"

  # Validate numeric
  if ! [[ "$line_no" =~ ^[0-9]+$ ]] || [ "$line_no" -le 0 ]; then
    echo "<pre class=\"ctx\"><em>No context available</em></pre>"
    return
  fi

  # Calculate window
  local start=$(( line_no - 2 ))
  local end=$(( line_no + 2 ))
  [ $start -lt 1 ] && start=1

  # Pull snippet with line numbers; mark offending line with __HL__ prefix
  # Then HTML-escape, then wrap highlighted line with <span class="hl">...</span>
  awk -v s="$start" -v e="$end" -v ln="$line_no" 'NR>=s && NR<=e {
      if (NR==ln) printf "__HL__%5d: %s\n", NR, $0;
      else        printf "      %5d: %s\n", NR, $0;
  }' "$file" \
  | html_escape \
  | sed -e 's/^__HL__/<span class="hl">/' \
        -e '/^<span class="hl">/ s/$/<\/span>/' \
  | sed '1s/^/<pre class="ctx">/; $s/$/<\/pre>/'  # wrap whole block in <pre>
}

# ----- Accumulators -----
declare -A FILE_TOTALS
declare -A FILE_ROWS   # per-file HTML rows (we'll append ready-to-insert <tr> rows)

GRAND_HIGH=0
GRAND_MED=0
GRAND_LOW=0
GRAND_INFO=0

# Map Severity ID to CSS class
id_class_for() {
  case "$1" in
    HIGH-001) echo "id-high" ;;
    MED-001)  echo "id-med" ;;
    LOW-001)  echo "id-low" ;;
    INFO-001) echo "id-info" ;;
    *)        echo "" ;;
  esac
}

# ----- Run one section (keeps original logic) -----
run_section () {
  local file="$1" theme="$2" cat_id="$3" count_var="$4"

  local out
  out=$(PERL5LIB=$PWD perlcritic --theme "$theme" "$file" 2>&1)

  # Parse each non-empty, non-"source OK" line
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    [[ "$line" == *"source OK"* ]] && continue

    # Extract parts
    # issue_text: everything before " at line X, column Y."
    local issue_text
    issue_text=$(echo "$line" | sed -E 's/^\[.*\] (.*) at line .*/\1/')

    # numeric line + col
    local line_no col_no
    line_no=$(echo "$line" | sed -nE 's/^.* at line ([0-9]+), column ([0-9]+)\..*/\1/p')
    col_no=$(echo "$line" | sed -nE 's/^.* at line ([0-9]+), column ([0-9]+)\..*/\2/p')

    # trailing description + "Severity: n"
    local desc_and_sev
    desc_and_sev=$(echo "$line" | sed -E 's/^.*\.  (.*)  \(Severity: ([0-9]+)\)$/\1|Severity: \2/')

    # HTML-safe fields
    local id_class
    id_class=$(id_class_for "$cat_id")

    local issue_html loc_html desc_html ctx_html
    issue_html=$(printf "%s" "$issue_text" | html_escape)
    loc_html=$(printf "Line %s, Col %s" "$line_no" "$col_no" | html_escape)
    desc_html=$(printf "%s" "$desc_and_sev" | html_escape | sed 's/|/ | /')

    # Build context snippet (monospace, offending line highlighted)
    ctx_html=$(make_context_html "$file" "$line_no")

    # one table row
    FILE_ROWS["$file"]+=$'<tr>'\
"<td class=\"$id_class\">$cat_id</td>"\
"<td>$issue_html</td>"\
"<td>$loc_html</td>"\
"<td>$desc_html $ctx_html</td>"\
$'</tr>\n'

  done <<< "$out"

  # Count real findings
  local count
  count=$(printf "%s\n" "$out" | sed '/^[[:space:]]*$/d' | grep -v 'source OK' | wc -l)
  eval "$count_var=$count"
}

# ----- Collect files -----
mapfile -d '' FILES < <(find "$TARGET_DIR" -type f -name "*.pl" -print0)
if [ "${#FILES[@]}" -eq 0 ]; then
  echo "No .pl files found in '$TARGET_DIR'."
  exit 0
fi

# ----- Scan all files -----
for file in "${FILES[@]}"; do
  HIGH_COUNT=0
  MED_COUNT=0
  LOW_COUNT=0
  INFO_COUNT=0

  run_section "$file" "perl_high_risk"            "HIGH-001" "HIGH_COUNT"
  run_section "$file" "perl_medium_threat"        "MED-001"  "MED_COUNT"
  run_section "$file" "perl_low_visibility"       "LOW-001"  "LOW_COUNT"
  run_section "$file" "perl_best_coding_practice" "INFO-001" "INFO_COUNT"

  GRAND_HIGH=$((GRAND_HIGH + HIGH_COUNT))
  GRAND_MED=$((GRAND_MED + MED_COUNT))
  GRAND_LOW=$((GRAND_LOW + LOW_COUNT))
  GRAND_INFO=$((GRAND_INFO + INFO_COUNT))

  TOTAL_FOR_FILE=$((HIGH_COUNT + MED_COUNT + LOW_COUNT + INFO_COUNT))
  FILE_TOTALS["$file"]=$TOTAL_FOR_FILE
done

# ----- Build Top 5 -----
RANKED=$(for f in "${!FILE_TOTALS[@]}"; do
  printf "%s\t%s\n" "${FILE_TOTALS[$f]}" "$f"
done | sort -nr -k1,1 | head -5)

# ----- Write HTML -----
cat > "$OUTPUT_PATH" <<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Perl SAST Ultra — Scan Report</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  :root {
    --bg:#0b0e14; --panel:#111422; --line:#1e2336;
    --txt:#e6e6e6; --muted:#a0a0a0;
    --high:#e74c3c; --med:#e67e22; --low:#3498db; --info:#2ecc71;
    --hl:#fff3a3;
  }
  body { margin:24px; background:var(--bg); color:var(--txt); font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial; }
  .wrap { max-width:1200px; margin:0 auto; }
  h1 { margin:0 0 4px; font-size:26px; color:#9cdcfe; }
  .meta { color:var(--muted); font-size:12px; margin-bottom:18px; }
  h2 { margin:26px 0 10px; font-size:18px; color:#9cdcfe; }
  h3 { margin:20px 0 8px; font-size:16px; color:#c3e88d; }
  table { width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--line); border-radius:10px; overflow:hidden; }
  th, td { padding:10px 12px; border-bottom:1px solid var(--line); vertical-align:top; }
  th { text-align:left; background:#141831; color:#cbd5e1; font-weight:600; }
  tr:last-child td { border-bottom:none; }
  tr:nth-child(even) td { background:#0f1324; }
  .id-high { color:var(--high); font-weight:700; }
  .id-med  { color:var(--med);  font-weight:700; }
  .id-low  { color:var(--low);  font-weight:700; }
  .id-info { color:var(--info); font-weight:700; }
  .ctx { margin-top:8px; background:#0c1022; border:1px solid var(--line); border-radius:8px; padding:10px; color:#cbd5e1; overflow:auto; white-space:pre; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
  .hl { background:var(--hl); color:#111; padding:0 2px; border-radius:4px; display:inline-block; width:100%; }
  .grid { display:grid; grid-template-columns: 1fr 1fr; gap:16px; }
  @media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
</style>
</head>
<body>
  <div class="wrap">
    <h1>Perl SAST Ultra — Scan Report</h1>
    <div class="meta">Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')</div>

    <div class="grid">
      <div>
        <h2>Summary (All Files)</h2>
        <table>
          <tr><th>Severity</th><th>Count</th></tr>
          <tr><td class="id-high">[HIGH-001] High</td><td>$GRAND_HIGH</td></tr>
          <tr><td class="id-med">[MED-001] Medium</td><td>$GRAND_MED</td></tr>
          <tr><td class="id-low">[LOW-001] Low</td><td>$GRAND_LOW</td></tr>
          <tr><td class="id-info">[INFO-001] Info</td><td>$GRAND_INFO</td></tr>
        </table>
      </div>
      <div>
        <h2>Top 5 Most Vulnerable Files</h2>
        <table>
          <tr><th>Rank</th><th>File</th><th>Total Issues</th></tr>
EOF

# Insert Top 5 rows
i=1
while IFS=$'\t' read -r count path; do
  [[ -z "$count" || -z "$path" ]] && continue
  echo "          <tr><td>$i</td><td>$(printf "%s" "$path" | html_escape)</td><td>$count</td></tr>" >> "$OUTPUT_PATH"
  i=$((i+1))
done <<< "$RANKED"

cat >> "$OUTPUT_PATH" <<EOF
        </table>
      </div>
    </div>

    <h2>Detailed Results</h2>
EOF

# Per-file detailed tables
for file in "${FILES[@]}"; do
  echo "    <h3>$(printf "%s" "$file" | html_escape)</h3>" >> "$OUTPUT_PATH"
  echo "    <table>" >> "$OUTPUT_PATH"
  echo "      <tr><th>ID</th><th>Issue</th><th>Location</th><th>Description &amp; Severity<br><small>Context (2 lines before/after; offending line highlighted)</small></th></tr>" >> "$OUTPUT_PATH"
  # Append prepared rows for this file
  printf "%s" "${FILE_ROWS[$file]}" >> "$OUTPUT_PATH"
  echo "    </table>" >> "$OUTPUT_PATH"
done

cat >> "$OUTPUT_PATH" <<EOF
    <div class="meta" style="margin-top:24px;">Report complete.</div>
  </div>
</body>
</html>
EOF

echo "HTML report written to: $OUTPUT_PATH"

